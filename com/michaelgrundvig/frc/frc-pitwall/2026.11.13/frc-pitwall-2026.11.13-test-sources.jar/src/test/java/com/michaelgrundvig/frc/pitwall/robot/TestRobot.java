package com.michaelgrundvig.frc.pitwall.robot;

import static com.michaelgrundvig.frc.world.robot.MechanismWiring.CANCODER;
import static com.michaelgrundvig.frc.world.robot.MechanismWiring.Controller.TALON_FX;
import static org.wpilib.units.Units.Degrees;
import static org.wpilib.units.Units.DegreesPerSecond;
import static org.wpilib.units.Units.DegreesPerSecondPerSecond;
import static org.wpilib.units.Units.Hertz;
import static org.wpilib.units.Units.Inches;
import static org.wpilib.units.Units.KilogramSquareMeters;
import static org.wpilib.units.Units.Kilograms;
import static org.wpilib.units.Units.Meters;
import static org.wpilib.units.Units.Milliseconds;
import static org.wpilib.units.Units.Rotations;

import com.michaelgrundvig.frc.world.physical.Inertia;
import com.michaelgrundvig.frc.world.robot.Body;
import com.michaelgrundvig.frc.world.robot.CameraConfig;
import com.michaelgrundvig.frc.world.robot.Driven.AbsoluteEncoder;
import com.michaelgrundvig.frc.world.robot.Drivetrain;
import com.michaelgrundvig.frc.world.robot.Gearing;
import com.michaelgrundvig.frc.world.robot.ImuMount;
import com.michaelgrundvig.frc.world.robot.Joint;
import com.michaelgrundvig.frc.world.robot.Link;
import com.michaelgrundvig.frc.world.robot.MechanismControl;
import com.michaelgrundvig.frc.world.robot.Motor;
import com.michaelgrundvig.frc.world.robot.Output;
import com.michaelgrundvig.frc.world.robot.Part;
import com.michaelgrundvig.frc.world.robot.Position;
import com.michaelgrundvig.frc.world.robot.PrismaticJoint;
import com.michaelgrundvig.frc.world.robot.Range;
import com.michaelgrundvig.frc.world.robot.RevoluteJoint;
import com.michaelgrundvig.frc.world.robot.RobotDefinition;
import com.michaelgrundvig.frc.world.robot.Sensor;
import org.wpilib.math.geometry.Translation3d;

/**
 * A robot for the Robot view's tests, with one joint of each kind the view draws and one interlock
 * of each kind: an intake's pivot with its roller on it, which runs only once the pivot is out; an
 * elevator carrying an arm, which keeps out of the bumper's band while the elevator is low; a
 * flywheel that runs one way; a claw that runs only while its beam is clear; a beam break and a
 * rangefinder.
 */
public final class TestRobot {
  private TestRobot() {}

  static final Position PIVOT_IN = Position.degrees("in", 1.5);
  static final Position PIVOT_OUT = Position.degrees("out", 130);

  /** An intake's pivot, which stands upright when it is in and swings forward and down. */
  static final RevoluteJoint PIVOT =
      Joint.pivot("pivot", Part.CHASSIS, Joint.PITCH_DOWN)
          .at(Meters.of(0.25), Meters.of(0), Meters.of(0.32))
          .range(Range.degrees(0, 135))
          .rest(PIVOT_IN)
          .carries(
              Link.box(
                  "intake arm",
                  new Translation3d(0, 0, 0.2),
                  Meters.of(0.05),
                  Meters.of(0.55),
                  Meters.of(0.36)))
          .positions(PIVOT_IN, PIVOT_OUT)
          .motors(Motor.KRAKEN_X60.through(Gearing.of(25)).on(TALON_FX.can(32)))
          .absoluteEncoder(CANCODER.can(34).offset(Rotations.of(0.82)))
          .control(
              MechanismControl.position(30)
                  .withProfile(DegreesPerSecond.of(450), DegreesPerSecondPerSecond.of(1700)));

  static final Output INTAKING = Output.rpm("intaking", 2000);
  static final Output OUTTAKING = Output.volts("outtaking", -4);

  /** Its roller, which runs both ways, and only once the pivot is out of the frame. */
  static final RevoluteJoint ROLLER =
      Joint.roller("roller", PIVOT)
          .at(Meters.of(0), Meters.of(0), Meters.of(0.35))
          .outputs(INTAKING, OUTTAKING)
          .motors(Motor.KRAKEN_X60.through(Gearing.of(3)).on(TALON_FX.can(31)))
          .runsOnlyWhen(PIVOT.atLeast(Degrees.of(110)))
          .control(MechanismControl.velocity(0.02));

  static final Position ELEVATOR_DOWN = Position.of("down", Inches.of(0));
  static final Position ELEVATOR_CLEAR = Position.of("clear", Inches.of(32));

  static final PrismaticJoint ELEVATOR =
      Joint.elevator("elevator", Part.CHASSIS)
          .at(Meters.of(0), Meters.of(0), Meters.of(0.1))
          .range(Range.meters(0, 1.2))
          .rest(ELEVATOR_DOWN)
          .positions(ELEVATOR_DOWN, ELEVATOR_CLEAR)
          .motors(
              Motor.KRAKEN_X60
                  .through(Gearing.of(5))
                  .drum(Inches.of(0.75))
                  .on(TALON_FX.can(20), TALON_FX.can(21).clockwise()))
          .absoluteEncoder(
              AbsoluteEncoder.of().ratio(1.0 / 12).on(CANCODER.can(24).offset(Rotations.of(0.31))))
          .control(MechanismControl.position(30).withKg(0.35));

  static final Position ARM_STOWED = Position.degrees("stowed", -45);
  static final Position ARM_SCORING = Position.degrees("scoring", 120);

  /** An arm on the elevator, kept out of the bumper's band while the elevator is too low. */
  static final RevoluteJoint ARM =
      Joint.pivot("arm", ELEVATOR, Joint.PITCH_UP)
          .at(Meters.of(0.1), Meters.of(0), Meters.of(0.3))
          .range(Range.degrees(-60, 150))
          .rest(ARM_STOWED)
          .positions(ARM_STOWED, ARM_SCORING)
          .motors(Motor.KRAKEN_X60.through(Gearing.of(60)).on(TALON_FX.can(22)))
          .absoluteEncoder(CANCODER.can(23).offset(Rotations.of(0.12)))
          .keepsOut(Range.degrees(-10, 30))
          .when(ELEVATOR.atMost(Inches.of(32)))
          .control(MechanismControl.position(30).withKg(0.35, Degrees.of(-90)));

  static final Output SHOOTING = Output.rpm("shooting", 3000);

  /** A flywheel, which runs one way and coasts when nothing is asked of it. */
  static final RevoluteJoint SHOOTER =
      Joint.roller("shooter", Part.CHASSIS)
          .at(Meters.of(-0.2), Meters.of(0), Meters.of(0.45))
          .outputs(SHOOTING)
          .motors(Motor.KRAKEN_X60.through(Gearing.of(1)).on(TALON_FX.can(52)))
          .control(MechanismControl.velocity(0.02).coasting());

  static final Sensor.Switch CLAW_BEAM = Sensor.Switch.beam("claw beam", PIVOT);

  static final Sensor.Rangefinder HOPPER =
      Sensor.Rangefinder.of("hopper", Part.CHASSIS, Meters.of(1.3), Degrees.of(27));

  static final Output GRIPPING = Output.rpm("gripping", 600);

  /** A claw's wheels, which run only while the claw's beam sees nothing. */
  static final RevoluteJoint CLAW =
      Joint.roller("claw", ARM)
          .at(Meters.of(0.3), Meters.of(0), Meters.of(0))
          .outputs(GRIPPING)
          .motors(Motor.KRAKEN_X44.through(Gearing.of(4)).on(TALON_FX.can(60)))
          .runsOnlyWhen(CLAW_BEAM.clear())
          .control(MechanismControl.velocity(0.02));

  private static final CameraConfig.ImageSensor CAMERA =
      CameraConfig.ImageSensor.of(1280, 800, Hertz.of(30))
          .fieldOfView(Degrees.of(80), CameraConfig.Across.DIAGONAL)
          .latency(Milliseconds.of(30))
          .sightRange(Meters.of(7));

  /** A camera on the chassis, facing forward and to the left, tilted up. */
  static final CameraConfig FRONT_CAMERA =
      CameraConfig.of("front", CAMERA)
          .at(Inches.of(10), Inches.of(8), Inches.of(20))
          .facing(Degrees.of(10), Degrees.of(20))
          .roll(Degrees.of(0))
          .noiseScale(1.0)
          .measured();

  /** A camera that rides on the arm, so it is where the elevator and the arm put it. */
  static final CameraConfig ARM_CAMERA =
      CameraConfig.of("on-arm", CAMERA)
          .at(Inches.of(4), Inches.of(0), Inches.of(2))
          .facing(Degrees.of(0), Degrees.of(0))
          .roll(Degrees.of(0))
          .noiseScale(1.0)
          .on(ARM)
          .measured();

  /** The robot. */
  public static RobotDefinition definition() {
    return RobotDefinition.of("test", body(), Drivetrain.inset(modules(), body(), Inches.of(2.625)))
        .withBackupImu(ImuMount.UNCHECKED)
        .withJoints(PIVOT, ROLLER, ELEVATOR, ARM, SHOOTER, CLAW)
        .withCameras(FRONT_CAMERA, ARM_CAMERA)
        .withSensors(CLAW_BEAM, HOPPER);
  }

  private static Body body() {
    return Body.frame(Inches.of(28), Inches.of(24), Inches.of(30))
        .bumpers(Inches.of(3.5), Inches.of(2.5), Inches.of(5.75))
        .weight(Kilograms.of(60))
        .inertia(
            Body.Turning.tensor(
                Inertia.builder().ixx(6).iyy(6).izz(6).ixy(0).ixz(0).iyz(0).build()))
        .cg(new Translation3d(0, 0, 0.2));
  }

  private static Drivetrain.Module modules() {
    return Drivetrain.Module.builder()
        .driveMotor(Motor.KRAKEN_X60)
        .steerMotor(Motor.KRAKEN_X44)
        .wheelRadius(Inches.of(2))
        .driveGearing(Gearing.of(6.75))
        .steerGearing(Gearing.of(12.8))
        .couplingRatio(0)
        .wheelCoefficientOfFriction(1.2)
        .driveInertia(KilogramSquareMeters.of(0.001))
        .steerInertia(KilogramSquareMeters.of(0.004))
        .build();
  }
}
