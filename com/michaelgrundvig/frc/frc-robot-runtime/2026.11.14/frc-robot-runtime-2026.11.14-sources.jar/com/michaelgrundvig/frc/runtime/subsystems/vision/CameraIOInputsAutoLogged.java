package com.michaelgrundvig.frc.runtime.subsystems.vision;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class CameraIOInputsAutoLogged extends CameraIO.CameraIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connected", connected);
    table.put("Frames", frames);
    table.put("Tags", tags);
    table.put("UnsolvedTags", unsolvedTags);
    table.put("SkippedFrames", skippedFrames);
    table.put("ExposureMs", exposureMs);
    table.put("Gain", gain);
    table.put("AutoExposure", autoExposure);
    table.put("BrightnessMedian", brightnessMedian);
    table.put("BrightnessHigh", brightnessHigh);
    table.put("ClippedShare", clippedShare);
    table.put("Sequence", sequence);
    table.put("Dropped", dropped);
    table.put("DetectMs", detectMs);
    table.put("VisorAddress", visorAddress);
    table.put("Error", error);
  }

  @Override
  public void fromLog(LogTable table) {
    connected = table.get("Connected", connected);
    frames = table.get("Frames", frames);
    tags = table.get("Tags", tags);
    unsolvedTags = table.get("UnsolvedTags", unsolvedTags);
    skippedFrames = table.get("SkippedFrames", skippedFrames);
    exposureMs = table.get("ExposureMs", exposureMs);
    gain = table.get("Gain", gain);
    autoExposure = table.get("AutoExposure", autoExposure);
    brightnessMedian = table.get("BrightnessMedian", brightnessMedian);
    brightnessHigh = table.get("BrightnessHigh", brightnessHigh);
    clippedShare = table.get("ClippedShare", clippedShare);
    sequence = table.get("Sequence", sequence);
    dropped = table.get("Dropped", dropped);
    detectMs = table.get("DetectMs", detectMs);
    visorAddress = table.get("VisorAddress", visorAddress);
    error = table.get("Error", error);
  }

  public CameraIOInputsAutoLogged clone() {
    CameraIOInputsAutoLogged copy = new CameraIOInputsAutoLogged();
    copy.connected = this.connected;
    copy.frames = this.frames.clone();
    copy.tags = this.tags.clone();
    copy.unsolvedTags = this.unsolvedTags.clone();
    copy.skippedFrames = this.skippedFrames;
    copy.exposureMs = this.exposureMs;
    copy.gain = this.gain;
    copy.autoExposure = this.autoExposure;
    copy.brightnessMedian = this.brightnessMedian;
    copy.brightnessHigh = this.brightnessHigh;
    copy.clippedShare = this.clippedShare;
    copy.sequence = this.sequence;
    copy.dropped = this.dropped;
    copy.detectMs = this.detectMs.clone();
    copy.visorAddress = this.visorAddress;
    copy.error = this.error;
    return copy;
  }
}
