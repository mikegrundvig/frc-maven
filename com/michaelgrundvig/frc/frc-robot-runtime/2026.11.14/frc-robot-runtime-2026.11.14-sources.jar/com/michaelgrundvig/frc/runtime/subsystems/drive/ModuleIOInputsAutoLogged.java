package com.michaelgrundvig.frc.runtime.subsystems.drive;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class ModuleIOInputsAutoLogged extends ModuleIO.ModuleIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("DriveConnected", driveConnected);
    table.put("DrivePositionRad", drivePositionRad);
    table.put("DriveVelocityRadPerSec", driveVelocityRadPerSec);
    table.put("DriveAppliedVolts", driveAppliedVolts);
    table.put("DriveStatorCurrentAmps", driveStatorCurrentAmps);
    table.put("DriveSupplyCurrentAmps", driveSupplyCurrentAmps);
    table.put("DriveTorqueLimited", driveTorqueLimited);
    table.put("DriveRestarted", driveRestarted);
    table.put("SteerConnected", steerConnected);
    table.put("SteerAngle", steerAngle);
    table.put("SteerAngleRotations", steerAngleRotations);
    table.put("SteerVelocityRadPerSec", steerVelocityRadPerSec);
    table.put("SteerAppliedVolts", steerAppliedVolts);
    table.put("SteerStatorCurrentAmps", steerStatorCurrentAmps);
    table.put("OdometryTimestampsNanos", odometryTimestampsNanos);
    table.put("OdometryDrivePositionsRad", odometryDrivePositionsRad);
    table.put("OdometrySteerAnglesRad", odometrySteerAnglesRad);
    table.put("Unconfigured", unconfigured);
    table.put("EncoderMagnet", encoderMagnet);
    table.put("EncoderFaults", encoderFaults);
  }

  @Override
  public void fromLog(LogTable table) {
    driveConnected = table.get("DriveConnected", driveConnected);
    drivePositionRad = table.get("DrivePositionRad", drivePositionRad);
    driveVelocityRadPerSec = table.get("DriveVelocityRadPerSec", driveVelocityRadPerSec);
    driveAppliedVolts = table.get("DriveAppliedVolts", driveAppliedVolts);
    driveStatorCurrentAmps = table.get("DriveStatorCurrentAmps", driveStatorCurrentAmps);
    driveSupplyCurrentAmps = table.get("DriveSupplyCurrentAmps", driveSupplyCurrentAmps);
    driveTorqueLimited = table.get("DriveTorqueLimited", driveTorqueLimited);
    driveRestarted = table.get("DriveRestarted", driveRestarted);
    steerConnected = table.get("SteerConnected", steerConnected);
    steerAngle = table.get("SteerAngle", steerAngle);
    steerAngleRotations = table.get("SteerAngleRotations", steerAngleRotations);
    steerVelocityRadPerSec = table.get("SteerVelocityRadPerSec", steerVelocityRadPerSec);
    steerAppliedVolts = table.get("SteerAppliedVolts", steerAppliedVolts);
    steerStatorCurrentAmps = table.get("SteerStatorCurrentAmps", steerStatorCurrentAmps);
    odometryTimestampsNanos = table.get("OdometryTimestampsNanos", odometryTimestampsNanos);
    odometryDrivePositionsRad = table.get("OdometryDrivePositionsRad", odometryDrivePositionsRad);
    odometrySteerAnglesRad = table.get("OdometrySteerAnglesRad", odometrySteerAnglesRad);
    unconfigured = table.get("Unconfigured", unconfigured);
    encoderMagnet = table.get("EncoderMagnet", encoderMagnet);
    encoderFaults = table.get("EncoderFaults", encoderFaults);
  }

  public ModuleIOInputsAutoLogged clone() {
    ModuleIOInputsAutoLogged copy = new ModuleIOInputsAutoLogged();
    copy.driveConnected = this.driveConnected;
    copy.drivePositionRad = this.drivePositionRad;
    copy.driveVelocityRadPerSec = this.driveVelocityRadPerSec;
    copy.driveAppliedVolts = this.driveAppliedVolts;
    copy.driveStatorCurrentAmps = this.driveStatorCurrentAmps;
    copy.driveSupplyCurrentAmps = this.driveSupplyCurrentAmps;
    copy.driveTorqueLimited = this.driveTorqueLimited;
    copy.driveRestarted = this.driveRestarted;
    copy.steerConnected = this.steerConnected;
    copy.steerAngle = this.steerAngle;
    copy.steerAngleRotations = this.steerAngleRotations;
    copy.steerVelocityRadPerSec = this.steerVelocityRadPerSec;
    copy.steerAppliedVolts = this.steerAppliedVolts;
    copy.steerStatorCurrentAmps = this.steerStatorCurrentAmps;
    copy.odometryTimestampsNanos = this.odometryTimestampsNanos.clone();
    copy.odometryDrivePositionsRad = this.odometryDrivePositionsRad.clone();
    copy.odometrySteerAnglesRad = this.odometrySteerAnglesRad.clone();
    copy.unconfigured = this.unconfigured;
    copy.encoderMagnet = this.encoderMagnet;
    copy.encoderFaults = this.encoderFaults;
    return copy;
  }
}
