package com.michaelgrundvig.frc.runtime.subsystems.mechanisms;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class PdhIOInputsAutoLogged extends PdhIO.PdhIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connected", connected);
    table.put("ChannelCurrentAmps", channelCurrentAmps);
    table.put("TotalCurrentAmps", totalCurrentAmps);
    table.put("Volts", volts);
  }

  @Override
  public void fromLog(LogTable table) {
    connected = table.get("Connected", connected);
    channelCurrentAmps = table.get("ChannelCurrentAmps", channelCurrentAmps);
    totalCurrentAmps = table.get("TotalCurrentAmps", totalCurrentAmps);
    volts = table.get("Volts", volts);
  }

  public PdhIOInputsAutoLogged clone() {
    PdhIOInputsAutoLogged copy = new PdhIOInputsAutoLogged();
    copy.connected = this.connected;
    copy.channelCurrentAmps = this.channelCurrentAmps.clone();
    copy.totalCurrentAmps = this.totalCurrentAmps;
    copy.volts = this.volts;
    return copy;
  }
}
