package com.michaelgrundvig.frc.runtime.venues;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class VenueIOInputsAutoLogged extends VenueIO.VenueIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Text", text);
    table.put("Problem", problem);
    table.put("InGit", inGit);
  }

  @Override
  public void fromLog(LogTable table) {
    text = table.get("Text", text);
    problem = table.get("Problem", problem);
    inGit = table.get("InGit", inGit);
  }

  public VenueIOInputsAutoLogged clone() {
    VenueIOInputsAutoLogged copy = new VenueIOInputsAutoLogged();
    copy.text = this.text;
    copy.problem = this.problem;
    copy.inGit = this.inGit;
    return copy;
  }
}
