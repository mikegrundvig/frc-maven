package com.michaelgrundvig.frc.runtime.subsystems.mechanisms;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class AbsoluteEncoderIOInputsAutoLogged extends AbsoluteEncoderIO.AbsoluteEncoderIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connected", connected);
    table.put("Share", share);
  }

  @Override
  public void fromLog(LogTable table) {
    connected = table.get("Connected", connected);
    share = table.get("Share", share);
  }

  public AbsoluteEncoderIOInputsAutoLogged clone() {
    AbsoluteEncoderIOInputsAutoLogged copy = new AbsoluteEncoderIOInputsAutoLogged();
    copy.connected = this.connected;
    copy.share = this.share;
    return copy;
  }
}
