package com.michaelgrundvig.frc.runtime.subsystems.mechanisms;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class SensorIOInputsAutoLogged extends SensorIO.SensorIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connected", connected);
    table.put("Tripped", tripped);
    table.put("Meters", meters);
  }

  @Override
  public void fromLog(LogTable table) {
    connected = table.get("Connected", connected);
    tripped = table.get("Tripped", tripped);
    meters = table.get("Meters", meters);
  }

  public SensorIOInputsAutoLogged clone() {
    SensorIOInputsAutoLogged copy = new SensorIOInputsAutoLogged();
    copy.connected = this.connected;
    copy.tripped = this.tripped;
    copy.meters = this.meters;
    return copy;
  }
}
