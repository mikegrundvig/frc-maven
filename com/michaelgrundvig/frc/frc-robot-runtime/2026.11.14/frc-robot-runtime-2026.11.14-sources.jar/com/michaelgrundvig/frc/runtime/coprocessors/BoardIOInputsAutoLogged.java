package com.michaelgrundvig.frc.runtime.coprocessors;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class BoardIOInputsAutoLogged extends BoardIO.BoardIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connection", connection);
    table.put("Why", why);
    table.put("Hostname", hostname);
    table.put("AgentDescribes", agentDescribes);
    table.put("PackPushes", packPushes);
    table.put("PackPushesSinceDescribed", packPushesSinceDescribed);
    table.put("CpuBusiestPercent", cpuBusiestPercent);
    table.put("CpuCapped", cpuCapped);
    table.put("HottestCelsius", hottestCelsius);
    table.put("ThermalMarginCelsius", thermalMarginCelsius);
    table.put("ThermalMarginLevel", thermalMarginLevel);
    table.put("UsbDisconnects", usbDisconnects);
    table.put("UsbDevices", usbDevices);
    table.put("UptimeSeconds", uptimeSeconds);
    table.put("Unavailable", unavailable);
  }

  @Override
  public void fromLog(LogTable table) {
    connection = table.get("Connection", connection);
    why = table.get("Why", why);
    hostname = table.get("Hostname", hostname);
    agentDescribes = table.get("AgentDescribes", agentDescribes);
    packPushes = table.get("PackPushes", packPushes);
    packPushesSinceDescribed = table.get("PackPushesSinceDescribed", packPushesSinceDescribed);
    cpuBusiestPercent = table.get("CpuBusiestPercent", cpuBusiestPercent);
    cpuCapped = table.get("CpuCapped", cpuCapped);
    hottestCelsius = table.get("HottestCelsius", hottestCelsius);
    thermalMarginCelsius = table.get("ThermalMarginCelsius", thermalMarginCelsius);
    thermalMarginLevel = table.get("ThermalMarginLevel", thermalMarginLevel);
    usbDisconnects = table.get("UsbDisconnects", usbDisconnects);
    usbDevices = table.get("UsbDevices", usbDevices);
    uptimeSeconds = table.get("UptimeSeconds", uptimeSeconds);
    unavailable = table.get("Unavailable", unavailable);
  }

  public BoardIOInputsAutoLogged clone() {
    BoardIOInputsAutoLogged copy = new BoardIOInputsAutoLogged();
    copy.connection = this.connection;
    copy.why = this.why;
    copy.hostname = this.hostname;
    copy.agentDescribes = this.agentDescribes;
    copy.packPushes = this.packPushes;
    copy.packPushesSinceDescribed = this.packPushesSinceDescribed;
    copy.cpuBusiestPercent = this.cpuBusiestPercent;
    copy.cpuCapped = this.cpuCapped;
    copy.hottestCelsius = this.hottestCelsius;
    copy.thermalMarginCelsius = this.thermalMarginCelsius;
    copy.thermalMarginLevel = this.thermalMarginLevel;
    copy.usbDisconnects = this.usbDisconnects;
    copy.usbDevices = this.usbDevices;
    copy.uptimeSeconds = this.uptimeSeconds;
    copy.unavailable = this.unavailable.clone();
    return copy;
  }
}
