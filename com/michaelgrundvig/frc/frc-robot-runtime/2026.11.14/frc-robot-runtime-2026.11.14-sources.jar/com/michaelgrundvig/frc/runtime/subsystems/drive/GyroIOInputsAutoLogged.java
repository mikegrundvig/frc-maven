package com.michaelgrundvig.frc.runtime.subsystems.drive;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class GyroIOInputsAutoLogged extends GyroIO.GyroIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connected", connected);
    table.put("Yaw", yaw);
    table.put("Restarted", restarted);
    table.put("YawVelocityRadPerSec", yawVelocityRadPerSec);
    table.put("PitchRad", pitchRad);
    table.put("RollRad", rollRad);
    table.put("AccelerationXMetersPerSecSq", accelerationXMetersPerSecSq);
    table.put("AccelerationYMetersPerSecSq", accelerationYMetersPerSecSq);
    table.put("OdometryTimestampsNanos", odometryTimestampsNanos);
    table.put("OdometryYawsRad", odometryYawsRad);
  }

  @Override
  public void fromLog(LogTable table) {
    connected = table.get("Connected", connected);
    yaw = table.get("Yaw", yaw);
    restarted = table.get("Restarted", restarted);
    yawVelocityRadPerSec = table.get("YawVelocityRadPerSec", yawVelocityRadPerSec);
    pitchRad = table.get("PitchRad", pitchRad);
    rollRad = table.get("RollRad", rollRad);
    accelerationXMetersPerSecSq = table.get("AccelerationXMetersPerSecSq", accelerationXMetersPerSecSq);
    accelerationYMetersPerSecSq = table.get("AccelerationYMetersPerSecSq", accelerationYMetersPerSecSq);
    odometryTimestampsNanos = table.get("OdometryTimestampsNanos", odometryTimestampsNanos);
    odometryYawsRad = table.get("OdometryYawsRad", odometryYawsRad);
  }

  public GyroIOInputsAutoLogged clone() {
    GyroIOInputsAutoLogged copy = new GyroIOInputsAutoLogged();
    copy.connected = this.connected;
    copy.yaw = this.yaw;
    copy.restarted = this.restarted;
    copy.yawVelocityRadPerSec = this.yawVelocityRadPerSec;
    copy.pitchRad = this.pitchRad;
    copy.rollRad = this.rollRad;
    copy.accelerationXMetersPerSecSq = this.accelerationXMetersPerSecSq;
    copy.accelerationYMetersPerSecSq = this.accelerationYMetersPerSecSq;
    copy.odometryTimestampsNanos = this.odometryTimestampsNanos.clone();
    copy.odometryYawsRad = this.odometryYawsRad.clone();
    return copy;
  }
}
