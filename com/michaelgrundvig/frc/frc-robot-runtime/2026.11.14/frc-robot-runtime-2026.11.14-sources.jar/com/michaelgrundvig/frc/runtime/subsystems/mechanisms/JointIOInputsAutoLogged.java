package com.michaelgrundvig.frc.runtime.subsystems.mechanisms;

import java.lang.Cloneable;
import java.lang.Override;
import org.littletonrobotics.junction.LogTable;
import org.littletonrobotics.junction.inputs.LoggableInputs;

public class JointIOInputsAutoLogged extends JointIO.JointIOInputs implements LoggableInputs, Cloneable {
  @Override
  public void toLog(LogTable table) {
    table.put("Connected", connected);
    table.put("Fresh", fresh);
    table.put("Position", position);
    table.put("Velocity", velocity);
    table.put("AbsolutePosition", absolutePosition);
    table.put("MotorPosition", motorPosition);
    table.put("MagnetBad", magnetBad);
    table.put("AppliedVolts", appliedVolts);
    table.put("StatorCurrentAmps", statorCurrentAmps);
    table.put("SupplyCurrentAmps", supplyCurrentAmps);
    table.put("ForwardLimit", forwardLimit);
    table.put("ReverseLimit", reverseLimit);
    table.put("Unconfigured", unconfigured);
    table.put("Restarted", restarted);
    table.put("FollowersRestarted", followersRestarted);
    table.put("EncoderRestarted", encoderRestarted);
    table.put("FollowersConnected", followersConnected);
    table.put("Faults", faults);
  }

  @Override
  public void fromLog(LogTable table) {
    connected = table.get("Connected", connected);
    fresh = table.get("Fresh", fresh);
    position = table.get("Position", position);
    velocity = table.get("Velocity", velocity);
    absolutePosition = table.get("AbsolutePosition", absolutePosition);
    motorPosition = table.get("MotorPosition", motorPosition);
    magnetBad = table.get("MagnetBad", magnetBad);
    appliedVolts = table.get("AppliedVolts", appliedVolts);
    statorCurrentAmps = table.get("StatorCurrentAmps", statorCurrentAmps);
    supplyCurrentAmps = table.get("SupplyCurrentAmps", supplyCurrentAmps);
    forwardLimit = table.get("ForwardLimit", forwardLimit);
    reverseLimit = table.get("ReverseLimit", reverseLimit);
    unconfigured = table.get("Unconfigured", unconfigured);
    restarted = table.get("Restarted", restarted);
    followersRestarted = table.get("FollowersRestarted", followersRestarted);
    encoderRestarted = table.get("EncoderRestarted", encoderRestarted);
    followersConnected = table.get("FollowersConnected", followersConnected);
    faults = table.get("Faults", faults);
  }

  public JointIOInputsAutoLogged clone() {
    JointIOInputsAutoLogged copy = new JointIOInputsAutoLogged();
    copy.connected = this.connected;
    copy.fresh = this.fresh;
    copy.position = this.position;
    copy.velocity = this.velocity;
    copy.absolutePosition = this.absolutePosition;
    copy.motorPosition = this.motorPosition;
    copy.magnetBad = this.magnetBad;
    copy.appliedVolts = this.appliedVolts;
    copy.statorCurrentAmps = this.statorCurrentAmps;
    copy.supplyCurrentAmps = this.supplyCurrentAmps;
    copy.forwardLimit = this.forwardLimit;
    copy.reverseLimit = this.reverseLimit;
    copy.unconfigured = this.unconfigured;
    copy.restarted = this.restarted;
    copy.followersRestarted = this.followersRestarted.clone();
    copy.encoderRestarted = this.encoderRestarted;
    copy.followersConnected = this.followersConnected.clone();
    copy.faults = this.faults.clone();
    return copy;
  }
}
