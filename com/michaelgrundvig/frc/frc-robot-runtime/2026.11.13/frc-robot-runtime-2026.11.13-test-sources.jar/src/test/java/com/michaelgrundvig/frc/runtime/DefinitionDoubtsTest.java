package com.michaelgrundvig.frc.runtime;

import static com.michaelgrundvig.frc.world.robot.MechanismWiring.Controller.TALON_FX;
import static org.assertj.core.api.Assertions.assertThat;
import static org.wpilib.units.Units.Degrees;
import static org.wpilib.units.Units.Meters;

import com.michaelgrundvig.frc.localization.SlipCheck;
import com.michaelgrundvig.frc.world.config.Finding;
import com.michaelgrundvig.frc.world.robot.CameraConfig;
import com.michaelgrundvig.frc.world.robot.Gearing;
import com.michaelgrundvig.frc.world.robot.Joint;
import com.michaelgrundvig.frc.world.robot.Link;
import com.michaelgrundvig.frc.world.robot.MechanismControl;
import com.michaelgrundvig.frc.world.robot.Motor;
import com.michaelgrundvig.frc.world.robot.Part;
import com.michaelgrundvig.frc.world.robot.Pdh;
import com.michaelgrundvig.frc.world.robot.Range;
import com.michaelgrundvig.frc.world.robot.RevoluteJoint;
import com.michaelgrundvig.frc.world.robot.RobotDefinition;
import com.michaelgrundvig.frc.world.robot.RobotDefinitionBuilder;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.wpilib.math.geometry.Translation3d;

/**
 * What the robot's definition doesn't know is said where it costs: what the robot's code reads,
 * wherever the program runs; what only the simulator reads, a link's mass, in the simulator alone.
 */
class DefinitionDoubtsTest {
  /** An arm whose plate nobody weighed, its kG not written. */
  private static final RevoluteJoint ARM =
      Joint.pivot("arm", Part.CHASSIS, Joint.PITCH_UP)
          .at(Meters.of(0.2), Meters.of(0), Meters.of(0.4))
          .range(Range.degrees(0, 90))
          .rest(Degrees.of(0))
          .carries(
              Link.box(
                  "arm plate",
                  new Translation3d(0.2, 0, 0),
                  Meters.of(0.4),
                  Meters.of(0.05),
                  Meters.of(0.05)))
          .motors(Motor.KRAKEN_X60.through(Gearing.of(50)))
          .control(
              MechanismControl.position(30).withHoming(MechanismControl.Homing.assumeAtRest()));

  private static final RobotDefinition ROBOT =
      RobotDefinitionBuilder.builder(ExampleRobot.SIM.definition())
          .name("doubts")
          .joints(List.of(ARM))
          .build();

  /**
   * The arm's missing kG is the robot's doubt; its plate's missing mass, the body's pitch and roll,
   * and the mass in no link are the simulator's alone.
   */
  @Test
  void theRobotSaysWhatItsCodeReadsAndTheSimulatorWhatOnlyItReads() {
    List<String> doubts =
        Doubts.lines(
            Doubts.of(ROBOT, SlipCheck.Settings.defaults(), RobotSim.massOf(ROBOT)),
            Finding.Scope.ROBOT);
    List<String> notes =
        Doubts.lines(
            Doubts.of(ROBOT, SlipCheck.Settings.defaults(), RobotSim.massOf(ROBOT)),
            Finding.Scope.SIMULATOR);

    assertThat(doubts)
        .contains(
            "not known: arm has no kG: it holds against gravity by kP alone, so it sits below its"
                + " targets until its kG is tuned and written: withKg(k) for a joint level at its"
                + " zero, withKg(k, angle) with the angle its weight pulls hardest at for one that"
                + " isn't, or 0 for a counterbalanced joint")
        .noneMatch(doubt -> doubt.contains("mass:") || doubt.contains("in no link"));
    assertThat(notes)
        .allMatch(note -> note.startsWith("simulator: "))
        .contains(
            "simulator: arm plate has no mass: arm's gravity comes from its kG, and arm plate adds"
                + " nothing to arm's inertia",
            "simulator: the body's pitch and roll are a box's, beside its given yaw: how the"
                + " simulator tips the robot is approximate")
        .anyMatch(note -> note.contains("is in no link"));
  }

  /**
   * The template's robot isn't weighed, and leaves its tread's grip and its modules' inertias to
   * the defaults: its weight, taken at the season's maximum, and the grip are the robot's doubts,
   * since its drive moves, feedforward and slip check read them; the inertias are the simulator's
   * notes. Its center of mass is given, so that's no note.
   */
  @Test
  void theTemplatesUnmeasuredGripIsTheRobotsDoubtAndItsInertiasTheSimulators() {
    RobotDefinition template = ExampleRobot.SIM.definition();
    List<String> doubts =
        Doubts.lines(
            Doubts.of(template, SlipCheck.Settings.defaults(), RobotSim.massOf(template)),
            Finding.Scope.ROBOT);
    List<String> notes =
        Doubts.lines(
            Doubts.of(template, SlipCheck.Settings.defaults(), RobotSim.massOf(template)),
            Finding.Scope.SIMULATOR);

    assertThat(doubts)
        .contains(
            "not known: the robot isn't weighed: it's taken at the season's maximum, 149.5 lb."
                + " with battery: the drive's moves and feedforward, the simulator's acceleration"
                + " and the links' mass budget rest on the rules, not the robot",
            "not known: the tread's grip isn't measured: it's 1.2, PathPlanner's default: drive"
                + " moves plan their acceleration on it, and the slip check judges by it: measure it"
                + " with a pull test (docs/characterization.md, tread friction)")
        .noneMatch(doubt -> doubt.contains("inertia isn't measured"));
    assertThat(notes)
        .contains(
            "simulator: the drive's own inertia isn't measured: it's 0.001 kg m², an estimate for"
                + " a 4 in wheel and a Kraken X60's rotor: how fast the simulator's wheels spin up"
                + " is a guess, though a small one beside the robot's mass they carry",
            "simulator: the steering's inertia isn't measured: it's 0.004 kg m², Phoenix Tuner X's"
                + " simulation value: how fast the simulator's modules steer at their current limit"
                + " is a guess")
        .noneMatch(note -> note.contains("grip") || note.contains("center of mass"));
  }

  /**
   * The template's roller, feeder and indexer have no mass, so the simulator turns each on its
   * motors' rotors alone, and the note says how soon they bring it to its fastest speed. Its
   * shooter carries a flywheel, so it has no note.
   */
  @Test
  void theTemplatesRollersSayHowFastTheirRotorsAloneSpinThemUp() {
    RobotDefinition example = ExampleRobot.COMPETITION.definition();
    List<String> notes =
        Doubts.lines(
            Doubts.of(example, SlipCheck.Settings.defaults(), RobotSim.massOf(example)),
            Finding.Scope.SIMULATOR);

    assertThat(notes)
        .contains(
            "simulator: roller has no mass: roller adds nothing to roller's inertia, so its rotors"
                + " alone bring it to intaking, 2000 rpm, in about 11 ms",
            "simulator: feeder has no mass: feeder adds nothing to feeder's inertia, so its rotors"
                + " alone bring it to feeding, 1000 rpm, in about 7 ms",
            "simulator: indexer has no mass: indexer adds nothing to indexer's inertia, so its"
                + " rotors alone bring it to feeding, 1500 rpm, in about 8 ms")
        .noneMatch(note -> note.contains("shooter has no mass"));
  }

  /**
   * A camera on Visor, on a robot (its device given), with no lens calibration places nothing: the
   * robot says so as it starts. One the simulator alone runs needs no lens, and one with its lens
   * is no doubt.
   */
  @Test
  void aVisorCameraWithNoLensCalibrationIsTheRobotsDoubt() {
    CameraConfig first = ExampleRobot.SIM.definition().cameras().get(0);
    CameraConfig.Software.Lens lens =
        CameraConfig.Software.Lens.builder()
            .width(first.sensor().widthPixels())
            .height(first.sensor().heightPixels())
            .fx(905.2)
            .fy(905.6)
            .cx(641.3)
            .cy(398.8)
            .distortion(List.of())
            .build();
    String device = "/dev/v4l/by-id/usb-front-video-index0";
    String said =
        "camera "
            + first.name()
            + " has no lens calibration: Visor sends its tags' corners and no poses, so it places"
            + " nothing. Calibrate it with Visor's tools/calibrate.py and give it the .lens(...)"
            + " that prints (docs/visor.md)";

    assertThat(doubtsWith(first, CameraConfig.Software.visor().device(device))).contains(said);
    assertThat(doubtsWith(first, CameraConfig.Software.VISOR)).noneMatch(said::equals);
    assertThat(doubtsWith(first, CameraConfig.Software.visor().device(device).lens(lens)))
        .noneMatch(said::equals);
  }

  /** The robot's doubts with its first camera on this software. */
  private static List<String> doubtsWith(CameraConfig first, CameraConfig.Software software) {
    List<CameraConfig> cameras = new ArrayList<>(ExampleRobot.SIM.definition().cameras());
    cameras.set(0, first.withSoftware(software));
    RobotDefinition robot =
        RobotDefinitionBuilder.builder(ExampleRobot.SIM.definition()).cameras(cameras).build();
    return Doubts.lines(
        Doubts.of(robot, SlipCheck.Settings.defaults(), RobotSim.massOf(robot)),
        Finding.Scope.ROBOT);
  }

  /** A kG written, even 0 for a counterbalanced arm, is no doubt. */
  @Test
  void aWrittenKgIsNoDoubt() {
    RobotDefinition tuned = ROBOT.with(ARM.retuned(control -> control.withKg(0)));

    assertThat(
            Doubts.lines(
                Doubts.of(tuned, SlipCheck.Settings.defaults(), RobotSim.massOf(tuned)),
                Finding.Scope.ROBOT))
        .noneMatch(doubt -> doubt.contains("kG"));
  }

  /**
   * With a PDH declared, a wired motor controller that doesn't say which channel feeds it is the
   * robot's doubt. The template's robot declares none, so it says nothing of feeds.
   */
  @Test
  void aWiredControllerWithNoChannelIsADoubtOnceThereIsAPdh() {
    RobotDefinition wired =
        RobotDefinitionBuilder.builder(
                ROBOT.with(ARM.motors(motors -> motors.on(TALON_FX.can(32)))))
            .pdh(Pdh.can(1))
            .build();

    assertThat(
            Doubts.lines(
                Doubts.of(wired, SlipCheck.Settings.defaults(), RobotSim.massOf(wired)),
                Finding.Scope.ROBOT))
        .contains(
            "not known: arm's motor controller 32 has no PDH channel: which channel feeds each, and"
                + " through what breaker, isn't checked: give each its own where it's wired,"
                + " .pdh(channel, breaker)");
    assertThat(
            Doubts.lines(
                Doubts.of(
                    ExampleRobot.SIM.definition(),
                    SlipCheck.Settings.defaults(),
                    RobotSim.massOf(ExampleRobot.SIM.definition())),
                Finding.Scope.ROBOT))
        .noneMatch(doubt -> doubt.contains("PDH"));
  }
}
