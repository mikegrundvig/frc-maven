package com.michaelgrundvig.frc.runtime.subsystems.mechanisms;

import static com.michaelgrundvig.frc.runtime.subsystems.mechanisms.JointFixtures.ELEVATOR;
import static com.michaelgrundvig.frc.runtime.subsystems.mechanisms.JointFixtures.PIVOT;
import static com.michaelgrundvig.frc.runtime.subsystems.mechanisms.JointFixtures.ROBOT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.within;
import static org.wpilib.units.Units.Seconds;

import com.michaelgrundvig.frc.runtime.subsystems.mechanisms.JointMechanism.State;
import com.michaelgrundvig.frc.world.record.JointState;
import com.michaelgrundvig.frc.world.robot.Joint;
import com.michaelgrundvig.frc.world.robot.MechanismControl.Homing;
import com.michaelgrundvig.frc.world.robot.RobotDefinition;
import com.michaelgrundvig.frc.world.robot.RobotDefinitionBuilder;
import com.michaelgrundvig.frc.world.robot.Sensor;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import org.jspecify.annotations.Nullable;
import org.junit.jupiter.api.Test;

/**
 * How a joint finds where it is, a loop at a time: into a hard stop, onto its switch, or from an
 * absolute encoder the robot reads, and where it stands meanwhile. No simulator: each loop is what
 * a test hands it, and where it's found is what it tells the joint.
 */
class JointHomingTest {
  private static final long LOOP = 20_000_000L;

  /** Where each homing told its joint it is. */
  private final List<Double> found = new ArrayList<>();

  private long now = 1_000_000_000L;

  private JointHoming homing(Joint joint, @Nullable Homing recipe) {
    return homing(joint, recipe, Optional.empty());
  }

  private JointHoming homing(Joint joint, @Nullable Homing recipe, Optional<Sensor.Switch> limit) {
    return new JointHoming(
        ROBOT.math(), joint, Optional.ofNullable(recipe), limit, Optional.empty(), found::add);
  }

  private JointHoming byEncoder(boolean closesLoop) {
    return new JointHoming(
        ROBOT.math(),
        PIVOT,
        Optional.empty(),
        Optional.empty(),
        Optional.of(new JointHoming.ReadEncoder(closesLoop, OptionalInt.of(1))),
        found::add);
  }

  /** A loop of a joint homed by its recipe, enabled throughout, moving at a speed. */
  private void loop(JointHoming homing, boolean enabled, boolean enabling, double velocity) {
    now += LOOP;
    homing.advance(now, enabled, enabling, velocity);
  }

  /** A joint with neither a recipe nor an encoder the robot reads is ready from the start. */
  @Test
  void aJointWithNothingToFindIsReady() {
    JointHoming homing = homing(PIVOT, null);

    homing.robotStarted(now);

    assertThat(homing.state()).isEqualTo(State.READY);
    assertThat(homing.recorded()).isEqualTo(JointState.READY);
    assertThat(homing.waits()).isFalse();
    assertThat(homing.fault()).isEmpty();
  }

  /**
   * Pushed into its stop on the first enable, the elevator is found at its range's end once it's
   * been still a quarter second, and isn't driven the loop it's found.
   */
  @Test
  void intoAHardStopItsFoundOnceStill() {
    JointHoming homing = homing(ELEVATOR, Homing.toHardStop(Sensor.Switch.Limit.End.LOWER));
    homing.robotStarted(now);
    State before = homing.state();
    loop(homing, true, true, -0.3);
    JointState recorded = homing.recorded();
    double volts = homing.pushVolts();
    for (int i = 0; i < 13; i++) {
      loop(homing, true, false, 0);
    }
    List<Double> early = List.copyOf(found);
    loop(homing, true, false, 0);
    boolean justFound = homing.justFound();
    homing.foundLoopWritten();

    assertThat(before).isEqualTo(State.UNHOMED);
    assertThat(recorded.standing()).isEqualTo(JointState.Standing.HOMING);
    assertThat(recorded.toward()).isEqualTo(JointState.Toward.LOWER_STOP);
    assertThat(recorded.secondsAllowed()).isCloseTo(9.5, within(0.05));
    assertThat(volts).isEqualTo(-2);
    assertThat(early).as("not still a quarter second yet").isEmpty();
    assertThat(found).containsExactly(0.0);
    assertThat(justFound).isTrue();
    assertThat(homing.state()).isEqualTo(State.READY);
    assertThat(homing.justFound()).isFalse();
  }

  /**
   * One that never finds its stop in its time is faulted, saying so, and homes again when asked;
   * disabled while it homes, it starts again on the next enable.
   */
  @Test
  void aHomingThatFindsNoStopIsFaulted() {
    JointHoming homing =
        homing(ELEVATOR, Homing.toHardStop(Sensor.Switch.Limit.End.LOWER, Seconds.of(0.3)));
    homing.robotStarted(now);
    loop(homing, true, true, -0.3);
    for (int i = 0; i < 15; i++) {
      loop(homing, true, false, -0.3);
    }
    String fault = homing.fault().orElse(null);
    homing.homeAgain(now, true);
    State again = homing.state();
    loop(homing, false, false, 0);
    State disabled = homing.state();
    loop(homing, true, true, 0);

    assertThat(fault)
        .isEqualTo("elevator's homing found no stop in 0.3 s, pushing toward its lower one");
    assertThat(again).isEqualTo(State.HOMING);
    assertThat(disabled).isEqualTo(State.UNHOMED);
    assertThat(homing.state()).isEqualTo(State.HOMING);
    homing.canceled();
    assertThat(homing.state()).as("its command canceled").isEqualTo(State.UNHOMED);
  }

  /**
   * Its homing canceled with the robot enabled, it's unhomed; a move waiting on it homes it again
   * at once. Disabled, the move waits for the next enable. Ready, or with nothing to find, nothing
   * waits.
   */
  @Test
  void aMoveWaitingOnACanceledHomingHomesItAgain() {
    JointHoming homing = homing(ELEVATOR, Homing.toHardStop(Sensor.Switch.Limit.End.LOWER));
    homing.robotStarted(now);
    loop(homing, true, true, -0.3);
    homing.canceled();
    State canceled = homing.state();
    boolean waitsDisabled = homing.moveWaits(now, false);
    State disabled = homing.state();
    boolean waits = homing.moveWaits(now, true);
    JointHoming none = homing(PIVOT, null);
    none.robotStarted(now);

    assertThat(canceled).isEqualTo(State.UNHOMED);
    assertThat(waitsDisabled).isTrue();
    assertThat(disabled).as("it homes on the next enable").isEqualTo(State.UNHOMED);
    assertThat(waits).isTrue();
    assertThat(homing.state()).isEqualTo(State.HOMING);
    assertThat(homing.recorded().toward()).isEqualTo(JointState.Toward.LOWER_STOP);
    assertThat(none.moveWaits(now, true)).isFalse();
    assertThat(none.state()).isEqualTo(State.READY);
  }

  /** The pivot's bottom switch, tripping at 5°: above where it rests, at 1.5°. */
  private static final Sensor.Switch PIVOT_DOWN =
      JointFixtures.limit("pivot down", PIVOT, Sensor.Switch.Limit.End.LOWER, Math.toRadians(5));

  /**
   * Starting on its switch, it backs off until the switch clears, then comes back until it trips,
   * and it's found halfway along that loop's travel past where the switch trips.
   */
  @Test
  void ontoItsSwitchItBacksOffFirstWhenItStartsOnIt() {
    SwitchReadings switches = new SwitchReadings(PIVOT_DOWN);
    JointHoming homing =
        homing(PIVOT, Homing.toSwitch(Sensor.Switch.Limit.End.LOWER), Optional.of(PIVOT_DOWN));
    homing.robotStarted(now);
    homing.advance(now, true, true, 0);
    double pushing = homing.pushVolts();
    switches.trip(PIVOT_DOWN, true);
    homing.switchRead(now, 0.02, switches.sensors());
    double backingOff = homing.pushVolts();
    homing.switchRead(now += LOOP, 0.06, switches.sensors());
    switches.trip(PIVOT_DOWN, false);
    homing.switchRead(now += LOOP, 0.1, switches.sensors());
    double headingIn = homing.pushVolts();
    switches.trip(PIVOT_DOWN, true);
    homing.switchRead(now += LOOP, 0.08, switches.sensors());

    assertThat(homing.switchEnd()).contains(Sensor.Switch.Limit.End.LOWER);
    assertThat(pushing).isEqualTo(-2);
    assertThat(backingOff).isEqualTo(2);
    assertThat(headingIn).isEqualTo(-2);
    assertThat(found).hasSize(1);
    assertThat(found.get(0)).isCloseTo(Math.toRadians(5) - 0.01, within(1e-12));
    assertThat(homing.justFound()).isTrue();
  }

  /** With its switch lost, it's faulted once its time has passed, saying the switch is lost. */
  @Test
  void aLostSwitchFaultsItsHoming() {
    SwitchReadings switches = new SwitchReadings(PIVOT_DOWN).lose(PIVOT_DOWN, true);
    JointHoming homing =
        homing(PIVOT, Homing.toSwitch(Sensor.Switch.Limit.End.LOWER), Optional.of(PIVOT_DOWN));
    homing.robotStarted(now);
    homing.advance(now, true, true, 0);
    for (int i = 0; i < 82; i++) {
      homing.switchRead(now += LOOP, 0.5, switches.sensors());
    }

    assertThat(homing.fault())
        .contains(
            "pivot's homing didn't trip pivot down in 1.6 s (its travel takes 0.6 s at 2.0 V):"
                + " pivot down is lost");
  }

  /**
   * A joint told to home to a switch it does not have is faulted the moment it would set off,
   * saying why, and is never pushed: not on the enable, not in any loop after, not when it is asked
   * to home again and not when a move waits on it.
   *
   * <p>No robot gets this far: its definition is refused as it is built ({@link
   * #noDefinitionHomesAJointToASwitchItLacks}). This is what the joint does if one ever did.
   */
  @Test
  void homedToASwitchItDoesNotHaveItIsFaultedAndNeverPushed() {
    SwitchReadings switches = new SwitchReadings(PIVOT_DOWN);
    JointHoming homing = homing(PIVOT, Homing.toSwitch(Sensor.Switch.Limit.End.LOWER));
    homing.robotStarted(now);
    State beforeItIsEnabled = homing.state();
    List<State> states = new ArrayList<>();

    loop(homing, true, true, 0);
    states.add(homing.state());
    // Its allowed time is 1.6 s. These loops run for 4 s.
    for (int i = 0; i < 200; i++) {
      loop(homing, true, false, 0);
      homing.switchRead(now, 0.5, switches.sensors());
      states.add(homing.state());
    }
    homing.homeAgain(now, true);
    states.add(homing.state());
    boolean aMoveWaits = homing.moveWaits(now, true);
    states.add(homing.state());

    assertThat(beforeItIsEnabled).isEqualTo(State.UNHOMED);
    assertThat(states).as("never homing, so never pushed").containsOnly(State.FAULTED);
    assertThat(aMoveWaits).isFalse();
    assertThat(homing.recorded())
        .isEqualTo(JointState.faulted(JointState.Fault.HOMING_HAS_NO_SWITCH));
    assertThat(homing.fault())
        .contains(
            "pivot's homing has no lower limit switch with a known position to home to,"
                + " so it isn't pushed: give its block one where it trips");
    assertThat(found).isEmpty();
  }

  /**
   * The same joint, disabled when it is asked to home again, is faulted on the next enable: asking
   * with the robot disabled only leaves it to home then.
   */
  @Test
  void homedToASwitchItDoesNotHaveItIsFaultedOnTheNextEnableToo() {
    JointHoming homing = homing(PIVOT, Homing.toSwitch(Sensor.Switch.Limit.End.LOWER));
    homing.robotStarted(now);
    loop(homing, true, true, 0);
    loop(homing, false, false, 0);

    homing.homeAgain(now, false);
    State disabled = homing.state();
    loop(homing, true, true, 0);

    assertThat(disabled).isEqualTo(State.UNHOMED);
    assertThat(homing.state()).isEqualTo(State.FAULTED);
  }

  /**
   * Every way a robot's definition could give a joint a switch to home to that it lacks is refused
   * as the definition is built, so no mechanism is ever made for one: no switch at all, a switch at
   * the other end only, a switch whose position is not known, and a practice robot that changes a
   * sound robot's joint into any of those.
   */
  @Test
  void noDefinitionHomesAJointToASwitchItLacks() {
    Homing toLowerSwitch = Homing.toSwitch(Sensor.Switch.Limit.End.LOWER);
    Joint.Revolute homesToItsSwitch =
        PIVOT.retuned(control -> JointFixtures.homed(control, toLowerSwitch));
    Sensor.Switch atTheOtherEnd =
        JointFixtures.limit("pivot up", PIVOT, Sensor.Switch.Limit.End.UPPER, Math.toRadians(130));
    Sensor.Switch notMeasured =
        JointFixtures.limit("pivot down", PIVOT, Sensor.Switch.Limit.End.LOWER);
    RobotDefinition sound =
        RobotDefinitionBuilder.builder(ROBOT)
            .sensors(List.of(PIVOT_DOWN))
            .build()
            .with(homesToItsSwitch);

    assertThatIllegalArgumentException()
        .isThrownBy(() -> ROBOT.with(homesToItsSwitch))
        .withMessageContaining("pivot homes to its lower limit switch, and its block has none");
    assertThatIllegalArgumentException()
        .isThrownBy(() -> withSensors(ROBOT, atTheOtherEnd).with(homesToItsSwitch))
        .withMessageContaining("pivot homes to its lower limit switch, and its block has none");
    assertThatIllegalArgumentException()
        .isThrownBy(() -> withSensors(ROBOT, notMeasured).with(homesToItsSwitch))
        .withMessageContaining("pivot homes to pivot down, whose position isn't known");
    assertThatIllegalArgumentException()
        .as("a practice robot that takes the switch away")
        .isThrownBy(() -> withSensors(sound))
        .withMessageContaining("pivot homes to its lower limit switch, and its block has none");
    assertThatIllegalArgumentException()
        .as("a practice robot whose switch has not been measured")
        .isThrownBy(() -> withSensors(sound, notMeasured))
        .withMessageContaining("pivot homes to pivot down, whose position isn't known");
    assertThatIllegalArgumentException()
        .as("a practice robot that homes to the other end")
        .isThrownBy(
            () ->
                sound.with(
                    PIVOT.retuned(
                        control ->
                            JointFixtures.homed(
                                control, Homing.toSwitch(Sensor.Switch.Limit.End.UPPER)))))
        .withMessageContaining("pivot homes to its upper limit switch, and its block has none");
    // The sound robot's joint finds its switch by the same lookup its mechanism uses.
    Joint homing = sound.joints().stream().filter(PIVOT::equals).findFirst().orElseThrow();
    LimitStops stops =
        new LimitStops(LimitStops.switchesOf(sound.math(), homing), sound.everySensor());
    assertThat(stops.homingSwitch(ControllerSettings.control(homing).homing()))
        .contains(PIVOT_DOWN);
  }

  /** The same robot with these sensors in place of its own list. */
  private static RobotDefinition withSensors(RobotDefinition robot, Sensor... sensors) {
    return RobotDefinitionBuilder.builder(robot).sensors(List.of(sensors)).build();
  }

  /**
   * Asked to home again, a joint with nothing to home by stays as it is: it has no stop or switch
   * to be pushed toward, so there is nothing to start.
   */
  @Test
  void askedToHomeAgainAJointWithNothingToHomeByStaysAsItIs() {
    JointHoming homing = homing(PIVOT, null);
    homing.robotStarted(now);

    homing.homeAgain(now, true);
    State enabled = homing.state();
    homing.homeAgain(now, false);

    assertThat(enabled).isEqualTo(State.READY);
    assertThat(homing.state()).isEqualTo(State.READY);
    assertThat(homing.pushVolts()).isZero();
  }

  /**
   * From its absolute encoder, it waits for the first reading, which tells the joint where it is:
   * driven from the next loop by its motor's new count, or at once by an encoder its loop closes
   * on.
   */
  @Test
  void anEncodersFirstReadingSaysWhereItIs() {
    JointHoming seeded = byEncoder(false);
    JointHoming closed = byEncoder(true);
    seeded.robotStarted(now);
    closed.robotStarted(now);
    State waiting = seeded.state();

    seeded.encoderRead(now, OptionalDouble.of(0.7));
    closed.encoderRead(now, OptionalDouble.of(0.7));

    assertThat(waiting).isEqualTo(State.UNHOMED);
    assertThat(seeded.waits()).isFalse();
    assertThat(found).containsExactly(0.7, 0.7);
    assertThat(seeded.justFound()).isTrue();
    assertThat(closed.justFound()).isFalse();
    assertThat(closed.state()).isEqualTo(State.READY);
    assertThat(seeded.awaitsEncoder()).isFalse();
  }

  /** With no reading in 2 s, it's faulted, saying so; a reading readies it. */
  @Test
  void anEncoderThatGivesNoReadingFaultsUntilItDoes() {
    JointHoming homing = byEncoder(false);
    homing.robotStarted(now);
    homing.encoderRead(now + 1_980_000_000L, OptionalDouble.empty());
    State early = homing.state();
    homing.encoderRead(now + 2_000_000_000L, OptionalDouble.empty());
    String fault = homing.fault().orElse(null);
    homing.encoderRead(now + 3_000_000_000L, OptionalDouble.of(0.4));

    assertThat(early).isEqualTo(State.UNHOMED);
    assertThat(fault)
        .isEqualTo(
            "pivot's absolute encoder gave no reading in 2.0 s, on port 1: it's seeded when it"
                + " does");
    assertThat(found).containsExactly(0.4);
    assertThat(homing.state()).isEqualTo(State.READY);
  }

  /**
   * The encoder its loop closes on lost, it's faulted and holds where it stops by its motor's
   * count; disabled, wherever it is as it's enabled; homed again meanwhile, it still holds there
   * while it waits; and the encoder's next reading readies it.
   */
  @Test
  void anEncoderItsLoopClosesOnLostHoldsItOnItsMotor() {
    JointHoming homing = byEncoder(true);
    homing.robotStarted(now);
    homing.encoderRead(now, OptionalDouble.of(0.5));

    homing.loopEncoderWatched(now += LOOP, true, false, 0.62, 0.6);
    String fault = homing.fault().orElse(null);
    OptionalDouble stopped = homing.heldOnMotor();
    homing.loopEncoderWatched(now += LOOP, false, false, 0.7, 0.68);
    OptionalDouble disabled = homing.heldOnMotor();
    homing.homeAgain(now, true);
    State again = homing.state();
    OptionalDouble waiting = homing.heldOnMotor();
    homing.encoderRead(now += LOOP, OptionalDouble.of(0.69));

    assertThat(fault)
        .isEqualTo(
            "pivot's absolute encoder is lost, on port 1: its loop closes on it, so it holds"
                + " where its motor says until the encoder answers");
    assertThat(stopped).hasValue(0.62);
    assertThat(disabled).hasValue(0.68);
    assertThat(again).isEqualTo(State.UNHOMED);
    assertThat(waiting).hasValue(0.68);
    assertThat(homing.state()).isEqualTo(State.READY);
    assertThat(homing.heldOnMotor()).isEmpty();
  }

  /**
   * Faulted for settings its motor controllers didn't take, its encoder's reading still tells its
   * motor where it is, and it stays faulted, homed again or not.
   */
  @Test
  void faultedOtherwiseItsEncoderStillSeedsIt() {
    JointHoming homing = byEncoder(false);
    homing.robotStarted(now);
    homing.faultFor(
        JointState.Fault.SETTINGS_NOT_TAKEN, "pivot's motor 32 didn't take its settings");
    homing.encoderRead(now, OptionalDouble.of(0.3));
    boolean awaitingAfter = homing.awaitsEncoder();
    homing.homeAgain(now, true);
    homing.encoderRead(now, OptionalDouble.of(0.35));

    assertThat(found).containsExactly(0.3, 0.35);
    assertThat(awaitingAfter).isFalse();
    assertThat(homing.state()).isEqualTo(State.FAULTED);
    assertThat(homing.recorded())
        .isEqualTo(JointState.faulted(JointState.Fault.SETTINGS_NOT_TAKEN));
    assertThat(homing.fault()).contains("pivot's motor 32 didn't take its settings");
  }
}
