package com.michaelgrundvig.frc.runtime.subsystems.mechanisms;

import static com.michaelgrundvig.frc.runtime.subsystems.mechanisms.JointFixtures.TURRET;
import static org.assertj.core.api.Assertions.assertThat;

import com.michaelgrundvig.frc.world.record.Holder;
import com.michaelgrundvig.frc.world.robot.JointAsk;
import com.michaelgrundvig.frc.world.robot.Sensor;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * A joint's limit switches beneath what it's asked, a loop at a time: no simulator, each switch
 * tripped as a test says.
 */
class LimitStopsTest {
  /** At 90° of the turret's swing, on its way to the back. */
  private static final Sensor.Switch TURRET_RIGHT =
      JointFixtures.limit(
          "turret right", TURRET, Sensor.Switch.Limit.End.UPPER, Math.toRadians(90));

  /** One at the turret's other end, its position not known. */
  private static final Sensor.Switch TURRET_LEFT =
      JointFixtures.limit("turret left", TURRET, Sensor.Switch.Limit.End.LOWER);

  private final SwitchReadings switches = new SwitchReadings(TURRET_RIGHT, TURRET_LEFT);

  /** The robot's sensors. What holds the turret names a switch by where it is among them. */
  private static final List<Sensor> SENSORS = List.of(TURRET_RIGHT, TURRET_LEFT);

  private static final Holder RIGHT = Holder.limitSwitch(SENSORS.indexOf(TURRET_RIGHT));
  private static final Holder LEFT = Holder.limitSwitch(SENSORS.indexOf(TURRET_LEFT));

  /** The turret held by its right switch, and by nothing else. */
  private static final List<Holder> RIGHT_TRIPPED = List.of(RIGHT);

  /** An interlock on the turret, which holds it above its limit switches. */
  private static final Holder AN_INTERLOCK = Holder.interlock(0);

  private final LimitStops turret = new LimitStops(List.of(TURRET_RIGHT, TURRET_LEFT), SENSORS);

  private static final Demand BACK = Demands.toPosition(Math.PI, 0.5);
  private static final Demand FRONT = Demands.toPosition(0, 0.5);

  /** Clear, nothing's held. */
  @Test
  void aClearSwitchHoldsNothing() {
    assertThat(turret.apply(BACK, 1, switches.sensors())).isSameAs(BACK);
  }

  /**
   * A position past a tripped switch holds where the joint was as it tripped, and says so; its
   * profile starts again from where it is, in the loop the hold begins.
   */
  @Test
  void aMovePastATrippedSwitchHoldsWhereItTripped() {
    switches.trip(TURRET_RIGHT, true);

    Demand held = turret.apply(BACK, 1.6, switches.sensors());

    assertThat(held).isEqualTo(new Demand(new JointAsk.ToPosition(1.6, 0.5), true, RIGHT_TRIPPED));
  }

  /**
   * In the loops after the hold begins the profile is left alone, however far the joint is pushed
   * off where it tripped, so the joint's position loop brings it back there. The demand is the very
   * same each loop: a steady hold makes no objects.
   */
  @Test
  void aHoldRestartsItsProfileOnlyAsItBegins() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());

    Demand pushedOn = turret.apply(BACK, 1.65, switches.sensors());
    Demand pushedBack = turret.apply(BACK, 1.57, switches.sensors());

    assertThat(pushedOn)
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.6, 0.5), false, RIGHT_TRIPPED));
    assertThat(pushedBack).isSameAs(pushedOn);
  }

  /** The same thing asked again as another object, as a command may each loop, is the same hold. */
  @Test
  void theSameThingAskedAgainIsTheSameHold() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());
    Demand lasting = turret.apply(BACK, 1.6, switches.sensors());

    Demand askedAgain = turret.apply(Demands.toPosition(Math.PI, 0.5), 1.62, switches.sensors());

    assertThat(askedAgain).isSameAs(lasting);
  }

  /**
   * The switch clears and trips again under the same move: a new hold, where the joint is as it
   * trips again, its profile starting again from there.
   */
  @Test
  void trippingAgainBeginsANewHoldWhereItIsThen() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());
    turret.apply(BACK, 1.6, switches.sensors());

    switches.trip(TURRET_RIGHT, false);
    Demand cleared = turret.apply(BACK, 1.59, switches.sensors());
    switches.trip(TURRET_RIGHT, true);
    Demand again = turret.apply(BACK, 1.62, switches.sensors());

    assertThat(cleared).isSameAs(BACK);
    assertThat(again)
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.62, 0.5), true, RIGHT_TRIPPED));
  }

  /**
   * Another position past the switch, asked while it holds: a new hold at the same point, at the
   * new ask's share of the cruise, its profile starting again once.
   */
  @Test
  void anotherPositionPastItBeginsANewHoldAtTheSamePoint() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());
    turret.apply(BACK, 1.6, switches.sensors());
    Demand further = Demands.toPosition(2.5, 0.25);

    Demand begun = turret.apply(further, 1.64, switches.sensors());
    Demand lasting = turret.apply(further, 1.64, switches.sensors());

    assertThat(begun)
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.6, 0.25), true, RIGHT_TRIPPED));
    assertThat(lasting)
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.6, 0.25), false, RIGHT_TRIPPED));
  }

  /**
   * A position short of where it tripped, asked while it holds, ends the hold; the first one asked
   * again is then held where the joint is by then.
   */
  @Test
  void aPositionShortOfItEndsTheHold() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());

    Demand away = turret.apply(FRONT, 1.6, switches.sensors());
    Demand back = turret.apply(BACK, 1.55, switches.sensors());

    assertThat(away).isSameAs(FRONT);
    assertThat(back).isEqualTo(new Demand(new JointAsk.ToPosition(1.55, 0.5), true, RIGHT_TRIPPED));
  }

  /**
   * A demand that restarts the profile itself, in a loop of a hold, still does; what already holds
   * the joint above the switch is said first, and a change in it begins a new hold.
   */
  @Test
  void whatComesInRestartingOrHeldStillIs() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());
    turret.apply(BACK, 1.6, switches.sensors());

    Demand restarting = turret.apply(BACK.restartingProfile(), 1.6, switches.sensors());
    Demand interlocked = BACK.heldTo(BACK.ask(), AN_INTERLOCK);
    Demand begun = turret.apply(interlocked, 1.6, switches.sensors());
    Demand lasting = turret.apply(interlocked, 1.6, switches.sensors());

    assertThat(restarting.restartProfile()).as("restarted from above").isTrue();
    assertThat(begun.restartProfile()).as("a new hold").isTrue();
    assertThat(lasting.restartProfile()).isFalse();
    assertThat(lasting.heldBy()).containsExactly(AN_INTERLOCK, RIGHT);
  }

  /** Leaving it is free, and once it clears, a move past it is held where it next trips. */
  @Test
  void leavingItIsFree() {
    switches.trip(TURRET_RIGHT, true);
    turret.apply(BACK, 1.6, switches.sensors());

    Demand leaving = turret.apply(FRONT, 1.65, switches.sensors());
    switches.trip(TURRET_RIGHT, false);
    turret.apply(BACK, 1.5, switches.sensors());
    switches.trip(TURRET_RIGHT, true);
    Demand again = turret.apply(BACK, 1.58, switches.sensors());

    assertThat(leaving).isSameAs(FRONT);
    assertThat(Demands.position(again)).isEqualTo(1.58);
  }

  /** An output toward a tripped switch goes neutral; away from it, it's applied. */
  @Test
  void anOutputTowardATrippedSwitchGoesNeutral() {
    switches.trip(TURRET_RIGHT, true);
    Demand toward = Demands.atVoltage(2);
    Demand away = Demands.atDutyCycle(-0.2);

    Demand stopped = turret.apply(toward, 1.6, switches.sensors());

    assertThat(stopped.ask()).isEqualTo(JointAsk.NEUTRAL);
    assertThat(stopped.heldBy()).containsExactly(RIGHT);
    assertThat(turret.apply(away, 1.6, switches.sensors())).isSameAs(away);
    assertThat(turret.apply(Demand.NEUTRAL, 1.6, switches.sensors()).heldBy()).isEmpty();
  }

  /**
   * An output pushed steadily at a tripped switch is held neutral by the very same demand each
   * loop, asked as the same object or as an equal one: a steady stop makes no objects. Anything
   * that changes begins another: another output, something else holding the joint above, or the
   * switch clearing and tripping again. Until 2026-10-11 every loop made a new demand.
   */
  @Test
  void anOutputHeldNeutralIsTheSameDemandWhileNothingChanges() {
    switches.trip(TURRET_RIGHT, true);
    Demand toward = Demands.atVoltage(2);
    Demand neutral = new Demand(JointAsk.NEUTRAL, false, RIGHT_TRIPPED);

    Demand begun = turret.apply(toward, 1.6, switches.sensors());
    Demand lasting = turret.apply(toward, 1.62, switches.sensors());
    Demand askedAgain = turret.apply(Demands.atVoltage(2), 1.61, switches.sensors());
    Demand harder = turret.apply(Demands.atVoltage(3), 1.61, switches.sensors());
    Demand interlocked =
        turret.apply(
            Demands.atVoltage(3).heldTo(new JointAsk.AtVoltage(1), AN_INTERLOCK),
            1.61,
            switches.sensors());
    Demand away = turret.apply(Demands.atVoltage(-2), 1.61, switches.sensors());
    Demand towardAgain = turret.apply(toward, 1.6, switches.sensors());
    switches.trip(TURRET_RIGHT, false);
    Demand cleared = turret.apply(toward, 1.5, switches.sensors());
    switches.trip(TURRET_RIGHT, true);
    Demand trippedAgain = turret.apply(toward, 1.6, switches.sensors());

    assertThat(begun).isEqualTo(neutral);
    assertThat(lasting).as("the next loop").isSameAs(begun);
    assertThat(askedAgain).as("asked again as another object").isSameAs(begun);
    assertThat(harder).as("another output").isEqualTo(neutral).isNotSameAs(begun);
    assertThat(interlocked)
        .isEqualTo(new Demand(JointAsk.NEUTRAL, false, List.of(AN_INTERLOCK, RIGHT)));
    assertThat(away.ask()).as("leaving is free").isEqualTo(new JointAsk.AtVoltage(-2));
    assertThat(towardAgain).isEqualTo(neutral);
    assertThat(cleared).isSameAs(toward);
    assertThat(trippedAgain).as("tripped again").isEqualTo(neutral).isNotSameAs(towardAgain);
  }

  /**
   * Where the joint was stopped is forgotten when the kind of hold changes. Held at a position on a
   * tripped switch, the joint is then pushed at the switch by an output, held neutral, and coasts
   * back. A position past the switch asked after that is held where the joint is by then, its
   * profile starting again once, and not back where the first hold was. The same is so each time
   * the hold changes kind, and each kind of hold is still the very same demand while it lasts.
   * Until 2026-10-11 the later position was held at the first hold's point, so the joint jumped
   * back to it.
   */
  @Test
  void aHoldThatChangesKindForgetsWhereTheJointWasStopped() {
    switches.trip(TURRET_RIGHT, true);
    Demand toward = Demands.atVoltage(2);
    Demand neutral = new Demand(JointAsk.NEUTRAL, false, RIGHT_TRIPPED);

    Demand held = turret.apply(BACK, 1.6, switches.sensors());
    Demand stilled = turret.apply(toward, 1.6, switches.sensors());
    Demand coasting = turret.apply(toward, 1.55, switches.sensors());
    Demand heldAgain = turret.apply(BACK, 1.52, switches.sensors());
    Demand lasting = turret.apply(BACK, 1.53, switches.sensors());
    Demand lastingOn = turret.apply(BACK, 1.51, switches.sensors());
    Demand stilledAgain = turret.apply(toward, 1.52, switches.sensors());
    Demand heldOnceMore = turret.apply(BACK, 1.5, switches.sensors());

    assertThat(held).isEqualTo(new Demand(new JointAsk.ToPosition(1.6, 0.5), true, RIGHT_TRIPPED));
    assertThat(stilled).isEqualTo(neutral);
    assertThat(coasting).as("held neutral, the next loop").isSameAs(stilled);
    assertThat(heldAgain)
        .as("a new hold where the joint is by then")
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.52, 0.5), true, RIGHT_TRIPPED));
    assertThat(lasting)
        .as("its profile started again once")
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.52, 0.5), false, RIGHT_TRIPPED));
    assertThat(lastingOn).as("the very same demand while it lasts").isSameAs(lasting);
    assertThat(stilledAgain).isEqualTo(neutral);
    assertThat(heldOnceMore)
        .as("and back again")
        .isEqualTo(new Demand(new JointAsk.ToPosition(1.5, 0.5), true, RIGHT_TRIPPED));
  }

  /** A lost switch holds no condition, so it stops nothing; nor does one never read. */
  @Test
  void aLostSwitchStopsNothing() {
    switches.trip(TURRET_RIGHT, true).lose(TURRET_RIGHT, true);

    assertThat(turret.apply(BACK, 1.6, switches.sensors())).isSameAs(BACK);
  }

  /** The switch homing finds it by: one at that end whose position is known. */
  @Test
  void itsSwitchAtAnEndIsOneWhosePositionIsKnown() {
    assertThat(turret.at(Sensor.Switch.Limit.End.UPPER)).contains(TURRET_RIGHT);
    assertThat(turret.at(Sensor.Switch.Limit.End.LOWER)).isEmpty();
    assertThat(new LimitStops(List.of(), SENSORS).at(Sensor.Switch.Limit.End.UPPER)).isEmpty();
    assertThat(new LimitStops(List.of(TURRET_RIGHT), SENSORS).at(Sensor.Switch.Limit.End.LOWER))
        .as("a switch at the other end only")
        .isEmpty();
  }

  /** Two tripped at once, a cut wire on one: each says so, and the joint goes neither way. */
  @Test
  void twoTrippedEachSaySo() {
    SwitchReadings both = new SwitchReadings(TURRET_RIGHT, TURRET_LEFT);
    both.trip(TURRET_RIGHT, true).trip(TURRET_LEFT, true);

    Demand right = turret.apply(Demands.atVoltage(2), 0, both.sensors());
    Demand left = turret.apply(Demands.atVoltage(-2), 0, both.sensors());

    assertThat(right.heldBy()).containsExactly(RIGHT);
    assertThat(left.heldBy()).containsExactly(LEFT);
  }
}
