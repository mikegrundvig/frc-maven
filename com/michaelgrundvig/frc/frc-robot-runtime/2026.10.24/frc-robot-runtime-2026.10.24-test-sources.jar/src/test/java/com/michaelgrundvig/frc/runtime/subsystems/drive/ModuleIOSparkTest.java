package com.michaelgrundvig.frc.runtime.subsystems.drive;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.wpilib.units.Units.Amps;
import static org.wpilib.units.Units.Rotations;

import com.michaelgrundvig.frc.runtime.ExampleRobot;
import com.michaelgrundvig.frc.runtime.RobotSim;
import com.michaelgrundvig.frc.world.robot.DrivetrainControl;
import com.michaelgrundvig.frc.world.robot.DrivetrainControlGainsBuilder;
import com.michaelgrundvig.frc.world.robot.DrivetrainControlLimitsBuilder;
import com.michaelgrundvig.frc.world.robot.DrivetrainGeometry;
import com.michaelgrundvig.frc.world.robot.DrivetrainGeometryModuleTypeBuilder;
import com.michaelgrundvig.frc.world.robot.MechanismWiring;
import com.michaelgrundvig.frc.world.robot.Motor;
import com.michaelgrundvig.frc.world.robot.SwerveWiring;
import com.revrobotics.PersistMode;
import com.revrobotics.REVLibError;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.ResetMode;
import com.revrobotics.sim.SparkAbsoluteEncoderSim;
import com.revrobotics.sim.SparkSimFaultManager;
import com.revrobotics.spark.ClosedLoopSlot;
import com.revrobotics.spark.SparkBase;
import com.revrobotics.spark.SparkFlex;
import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkSim;
import com.revrobotics.spark.config.SparkBaseConfig;
import com.revrobotics.spark.config.SparkFlexConfig;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.revrobotics.util.Signal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.wpilib.hardware.bus.CANPort;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.system.DCMotor;

/**
 * A MAXSwerve module on REV's simulated SPARKs: what it reads, in the template's units, and what it
 * tells the SPARKs, in theirs.
 */
@ExtendWith(RobotSim.class)
class ModuleIOSparkTest {
  /** REV's MAXSwerve: a Vortex driving through the template's gearing, a NEO 550 steering. */
  private static final DrivetrainGeometry.ModuleType MAX_SWERVE =
      DrivetrainGeometryModuleTypeBuilder.builder(
              ExampleRobot.SIM.definition().drivetrain().corners().get(0).module())
          .driveMotor(Motor.NEO_VORTEX)
          .steerMotor(Motor.NEO_550)
          .couplingRatio(0)
          .build();

  private static ModuleIOSpark module(int drive, int steer, double offsetTurns) {
    return new ModuleIOSpark(
        SwerveWiring.ModuleWiring.builder()
            .driveId(drive)
            .steerId(steer)
            .encoderOffset(Rotations.of(offsetTurns))
            .driveInverted(false)
            .steerInverted(true)
            .encoderInverted(true)
            .build(),
        CANPort.CAN_S0,
        MechanismWiring.Controller.SPARK_FLEX,
        MechanismWiring.Controller.SPARK_MAX,
        MAX_SWERVE);
  }

  /**
   * The wheel turns the drive's rotor turns through its gearing, and the module points where its
   * absolute encoder reads, with its offset: 0.3 of a turn read, less 0.1, is 0.2 of a turn.
   */
  @Test
  void itReadsTheWheelThroughItsGearingAndTheAngleWithItsOffset() {
    ModuleIOSpark io = module(11, 12, -0.1);
    double gearing = MAX_SWERVE.driveGearing().ratio();
    SparkSim drive = new SparkSim(io.drive(), DCMotor.getNeoVortex(1));
    drive.setPosition(2 * gearing);
    // REV's simulation hands a position on to its encoder as it steps.
    drive.iterate(0, 12, 0.02);
    new SparkAbsoluteEncoderSim((SparkMax) io.steer()).setPosition(0.3);
    ModuleIO.ModuleIOInputs inputs = new ModuleIO.ModuleIOInputs();

    io.updateInputs(inputs);

    assertThat(inputs.drivePositionRad)
        .as("two turns of the wheel")
        .isCloseTo(4 * Math.PI, within(1e-4));
    assertThat(inputs.steerAngle.getRotations()).isCloseTo(0.2, within(1e-6));
    assertThat(inputs.odometryTimestampsNanos).hasSize(1);
    assertThat(inputs.odometrySteerAnglesRad[0]).isCloseTo(0.4 * Math.PI, within(1e-5));
  }

  /**
   * A frame that does not come reads as REV's default, 0, which is also what a wheel that has not
   * turned and an encoder at its zero read. So the module's last readings stand instead: the wheel
   * stays two turns on, the module at 0.2 of a turn, and this loop's odometry reading is the last
   * one again, so odometry sees a wheel that did not move. A wheel read at 0 would have rolled two
   * turns back in one loop, at an angle off by the encoder's whole reading. The frames that come
   * next are read again.
   */
  @Test
  void aFrameThatDoesntComeLeavesTheLastReading() {
    ModuleIOSpark io = module(17, 18, -0.1);
    double gearing = MAX_SWERVE.driveGearing().ratio();
    SparkSim drive = new SparkSim(io.drive(), DCMotor.getNeoVortex(1));
    drive.setPosition(2 * gearing);
    drive.iterate(120, 12, 0.02);
    SparkAbsoluteEncoderSim encoder = new SparkAbsoluteEncoderSim((SparkMax) io.steer());
    encoder.setPosition(0.3);
    encoder.setVelocity(30);
    ModuleIO.ModuleIOInputs inputs = new ModuleIO.ModuleIOInputs();
    io.updateInputs(inputs);
    double wheel = inputs.drivePositionRad;
    double wheelSpeed = inputs.driveVelocityRadPerSec;
    double angle = inputs.steerAngle.getRotations();
    double turning = inputs.steerVelocityRadPerSec;
    double odometryWheel = inputs.odometryDrivePositionsRad[0];
    double odometryAngle = inputs.odometrySteerAnglesRad[0];
    Signal<Double> lost = Signal.ofError(0.0, REVLibError.kTimeout, 0);

    io.updateInputs(inputs, lost, lost, lost, lost);
    double keptWheel = inputs.drivePositionRad;
    double keptWheelSpeed = inputs.driveVelocityRadPerSec;
    double keptAngle = inputs.steerAngle.getRotations();
    double keptTurning = inputs.steerVelocityRadPerSec;
    double[] keptOdometryWheel = inputs.odometryDrivePositionsRad;
    double[] keptOdometryAngle = inputs.odometrySteerAnglesRad;
    drive.setPosition(3 * gearing);
    drive.iterate(120, 12, 0.02);
    io.updateInputs(inputs);

    // REV's simulation carries the wheel a little on as it steps at a speed.
    assertThat(wheel).as("two turns of the wheel and a little").isCloseTo(4 * Math.PI, within(0.1));
    assertThat(wheelSpeed).isPositive();
    assertThat(angle).isCloseTo(0.2, within(1e-6));
    assertThat(turning).as("30 RPM of the module").isCloseTo(Math.PI, within(1e-6));
    assertThat(keptWheel).as("not 0").isEqualTo(wheel);
    assertThat(keptWheelSpeed).isEqualTo(wheelSpeed);
    assertThat(keptAngle).as("not its offset").isEqualTo(angle);
    assertThat(keptTurning).isEqualTo(turning);
    assertThat(keptOdometryWheel)
        .as("odometry's wheel did not move")
        .containsExactly(odometryWheel);
    assertThat(keptOdometryAngle).containsExactly(odometryAngle);
    assertThat(inputs.drivePositionRad)
        .as("the next frame is read again")
        .isCloseTo(6 * Math.PI, within(0.1));
  }

  /**
   * Each frame is kept on its own: the steering's angle that does not come leaves the last angle,
   * while the wheel, whose frame came, is read on.
   */
  @Test
  void aSteeringFrameThatDoesntComeLeavesTheWheelReadOn() {
    ModuleIOSpark io = module(19, 25, -0.1);
    double gearing = MAX_SWERVE.driveGearing().ratio();
    SparkSim drive = new SparkSim(io.drive(), DCMotor.getNeoVortex(1));
    drive.setPosition(2 * gearing);
    drive.iterate(0, 12, 0.02);
    new SparkAbsoluteEncoderSim((SparkMax) io.steer()).setPosition(0.3);
    ModuleIO.ModuleIOInputs inputs = new ModuleIO.ModuleIOInputs();
    io.updateInputs(inputs);
    Signal<Double> lost = Signal.ofError(0.0, REVLibError.kTimeout, 0);
    RelativeEncoder motor = io.drive().getEncoder();

    drive.setPosition(3 * gearing);
    drive.iterate(0, 12, 0.02);
    io.updateInputs(inputs, motor.getPosition(), motor.getVelocity(), lost, lost);

    assertThat(inputs.steerAngle.getRotations()).as("the last angle").isCloseTo(0.2, within(1e-6));
    assertThat(inputs.odometrySteerAnglesRad[0]).isCloseTo(0.4 * Math.PI, within(1e-5));
    assertThat(inputs.drivePositionRad).as("three turns").isCloseTo(6 * Math.PI, within(1e-4));
    assertThat(inputs.odometryDrivePositionsRad[0]).isCloseTo(6 * Math.PI, within(1e-4));
  }

  /**
   * An angle goes to the steering SPARK in its encoder's own reading, the offset taken back off,
   * from 0 to 1; a wheel speed to the drive SPARK in rotor RPM, with the robot's feedforward.
   */
  @Test
  void itAsksInTheSparksUnits() {
    ModuleIO io = module(13, 14, 0.25);
    ModuleIOSpark spark = (ModuleIOSpark) io;
    SparkSim steer = new SparkSim(spark.steer(), DCMotor.getNeo550(1));
    SparkSim drive = new SparkSim(spark.drive(), DCMotor.getNeoVortex(1));
    steer.enable();
    drive.enable();

    io.setSteerAngle(Rotation2d.fromRotations(0.1));
    io.setDriveVelocity(2 * Math.PI, 1.5);
    steer.iterate(0, 12, 0.02);
    drive.iterate(0, 12, 0.02);

    assertThat(steer.getSetpoint())
        .as("0.1 less 0.25, round to 0.85")
        .isCloseTo(0.85, within(1e-6));
    assertThat(drive.getSetpoint())
        .as("a turn of the wheel a second")
        .isCloseTo(MAX_SWERVE.driveGearing().ratio() * 60, within(1e-3));
  }

  /** The template's gains reach the SPARKs' loops as shares of 12 V, in their units. */
  @Test
  void itsGainsReachTheLoopsInTheirUnits() {
    ModuleIOSpark io = module(15, 16, 0);
    DrivetrainControl control = ExampleRobot.SIM.drivetrain();

    io.configure(control.gains(), control.limits());

    double wheelRadius = MAX_SWERVE.wheelRadius().in(org.wpilib.units.Units.Meters);
    double gearing = MAX_SWERVE.driveGearing().ratio();
    double driveKp = control.gains().driveKp() * 2 * Math.PI * wheelRadius / gearing / 60 / 12;
    double steerKp = control.gains().steerKp() * 2 * Math.PI / 12;
    assertThat(((SparkFlex) io.drive()).configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0))
        .isCloseTo(driveKp, within(1e-6 * driveKp + 1e-9));
    assertThat(((SparkMax) io.steer()).configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0))
        .isCloseTo(steerKp, within(1e-6 * steerKp));
  }

  /** REV's sticky warning that a SPARK has reset, which it sets as it starts. */
  private static final SparkBase.Warnings HAS_RESET =
      new SparkBase.Warnings(false, false, false, false, false, false, true, false);

  /**
   * A module's SPARK that restarts comes back with what was saved on it at startup, without the
   * gains and limits tuned since. Each of the module's two SPARKs says it restarted in its sticky
   * warnings, and is sent the session's tuning again: the drive's first, while the steering, which
   * did not restart, is left alone, and then the steering's. REV's simulation keeps what it was
   * told through a restart, so the test puts each SPARK back on its startup tuning, as a restart
   * would.
   */
  @Test
  void aRestartedSparkIsToldItsTuningAgain() {
    ModuleIOSpark io = module(26, 6, 0);
    SparkFlex drive = (SparkFlex) io.drive();
    SparkMax steer = (SparkMax) io.steer();
    DrivetrainControl control = ExampleRobot.SIM.drivetrain();
    DrivetrainControl.Gains tunedGains =
        DrivetrainControlGainsBuilder.builder(control.gains())
            .driveKp(2 * control.gains().driveKp())
            .steerKp(2 * control.gains().steerKp())
            .build();
    DrivetrainControl.Limits tunedLimits =
        DrivetrainControlLimitsBuilder.builder(control.limits())
            .driveStatorCurrent(Amps.of(33))
            .steerStatorCurrent(Amps.of(17))
            .build();
    io.configure(control.gains(), control.limits());
    double driveKpAtStartup = drive.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0);
    double steerKpAtStartup = steer.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0);
    int driveAmpsAtStartup = drive.configAccessor.getSmartCurrentLimit();
    int steerAmpsAtStartup = steer.configAccessor.getSmartCurrentLimit();
    io.configure(tunedGains, tunedLimits);
    ModuleIO.ModuleIOInputs inputs = new ModuleIO.ModuleIOInputs();
    // Each SPARK's warning reads clear once, after the module cleared it as it started.
    readUntilItAsksAboutRestarts(io, inputs);

    fallBackToStartup(drive, new SparkFlexConfig(), driveKpAtStartup, driveAmpsAtStartup);
    fallBackToStartup(steer, new SparkMaxConfig(), steerKpAtStartup, steerAmpsAtStartup);
    new SparkSimFaultManager(drive).setStickyWarnings(HAS_RESET);
    readUntilItAsksAboutRestarts(io, inputs);
    double driveKp = drive.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0);
    int driveAmps = drive.configAccessor.getSmartCurrentLimit();
    double steerKpLeftAlone = steer.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0);
    new SparkSimFaultManager(steer).setStickyWarnings(HAS_RESET);
    readUntilItAsksAboutRestarts(io, inputs);

    assertThat(driveKp)
        .as("the drive's tuned kP, again")
        .isCloseTo(2 * driveKpAtStartup, within(1e-6 * driveKpAtStartup + 1e-12));
    assertThat(driveAmps).as("the drive's tuned current limit, again").isEqualTo(33);
    assertThat(steerKpLeftAlone)
        .as("the steering did not restart, so nothing is sent to it")
        .isEqualTo(steerKpAtStartup);
    assertThat(steer.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0))
        .as("the steering's tuned kP, again")
        .isCloseTo(2 * steerKpAtStartup, within(1e-6 * steerKpAtStartup));
    assertThat(steer.configAccessor.getSmartCurrentLimit())
        .as("the steering's tuned current limit, again")
        .isEqualTo(17);
  }

  /**
   * A restart is acted on once: the tuning is sent again as the restart is reported, and not in the
   * loops after it.
   */
  @Test
  void aRestartIsActedOnOnce() {
    ModuleIOSpark io = module(2, 4, 0);
    SparkFlex drive = (SparkFlex) io.drive();
    DrivetrainControl control = ExampleRobot.SIM.drivetrain();
    io.configure(control.gains(), control.limits());
    double kPAtStartup = drive.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0);
    int ampsAtStartup = drive.configAccessor.getSmartCurrentLimit();
    io.configure(
        DrivetrainControlGainsBuilder.builder(control.gains())
            .driveKp(2 * control.gains().driveKp())
            .build(),
        control.limits());
    ModuleIO.ModuleIOInputs inputs = new ModuleIO.ModuleIOInputs();
    readUntilItAsksAboutRestarts(io, inputs);
    new SparkSimFaultManager(drive).setStickyWarnings(HAS_RESET);
    readUntilItAsksAboutRestarts(io, inputs);
    double sentAgain = drive.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0);

    // The loops after the restart was reported: whatever the SPARK holds now is not written over.
    fallBackToStartup(drive, new SparkFlexConfig(), kPAtStartup, ampsAtStartup);
    readUntilItAsksAboutRestarts(io, inputs);
    readUntilItAsksAboutRestarts(io, inputs);

    assertThat(sentAgain).as("the tuned kP, sent again").isGreaterThan(1.5 * kPAtStartup);
    assertThat(drive.configAccessor.closedLoop.getP(ClosedLoopSlot.kSlot0))
        .as("nothing was sent after the one restart")
        .isEqualTo(kPAtStartup);
  }

  /** Reads the module through enough loops that it asks its SPARKs about restarts once. */
  private static void readUntilItAsksAboutRestarts(
      ModuleIOSpark io, ModuleIO.ModuleIOInputs inputs) {
    for (int loop = 0; loop < ModuleIOSpark.RESTART_LOOPS; loop++) {
      io.updateInputs(inputs);
    }
  }

  /** Puts a SPARK's gain and current limit back as they were saved at startup. */
  private static void fallBackToStartup(
      SparkBase spark, SparkBaseConfig blank, double kP, int statorAmps) {
    blank.smartCurrentLimit(statorAmps);
    blank.closedLoop.p(kP, ClosedLoopSlot.kSlot0);
    spark.configure(blank, ResetMode.kNoResetSafeParameters, PersistMode.kNoPersistParameters);
  }
}
