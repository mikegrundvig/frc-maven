package com.michaelgrundvig.frc.world.physical;

import static com.michaelgrundvig.frc.world.config.Rules.nonNegative;
import static com.michaelgrundvig.frc.world.config.Rules.shown;
import static org.wpilib.units.Units.Kilograms;

import com.michaelgrundvig.frc.world.config.Checks;
import com.michaelgrundvig.frc.world.config.ConfigRecord;
import com.michaelgrundvig.frc.world.config.Rule;
import java.util.List;
import java.util.Optional;
import org.wpilib.math.geometry.Transform3d;
import org.wpilib.math.geometry.Translation3d;
import org.wpilib.units.measure.Mass;

/**
 * How much a part weighs, where its weight is centered, and how hard it is to turn: all a physics
 * engine needs to move it, and what gravity's pull on a mechanism comes from. In the part's own
 * frame: a whole robot's, or a link's.
 *
 * <p>What isn't known is zero, not a guess ({@link #NONE}): a link nobody has weighed has no mass,
 * centered on its frame's origin, and turns freely. Everything derived from it stays consistent at
 * zero: no weight to hold up, nothing added to what it hangs from.
 *
 * @param mass how much it weighs: zero when nobody knows
 * @param cg its center of mass, in its frame, in meters
 * @param inertia how hard it is to turn, about its center of mass, along its frame's axes: zero
 *     when nobody knows, or for a point mass
 */
@ConfigRecord
public record MassProperties(Mass mass, Translation3d cg, Inertia inertia) {
  /**
   * None known: no mass, centered on its frame's origin (a link's joint), and no inertia. A link
   * starts here until CAD or a scale gives its own; the robot's missing-data report lists each.
   */
  public static final MassProperties NONE =
      MassPropertiesBuilder.builder()
          .mass(Kilograms.of(0))
          .cg(Translation3d.ZERO)
          .inertia(Inertia.ZERO)
          .build();

  public MassProperties {
    Checks.on(MassProperties.class)
        .field("mass", mass, nonNegative())
        .field("cg", cg, Rule.of(MassProperties::whyNotAPoint))
        .orThrow();
  }

  /** Why a center of mass is no point, if it is not: one of its numbers is missing or infinite. */
  private static Optional<String> whyNotAPoint(Translation3d point) {
    // Each number is asked by itself: three that are each finite can add up to more than a number
    // holds.
    boolean numbersAll =
        Double.isFinite(point.getX())
            && Double.isFinite(point.getY())
            && Double.isFinite(point.getZ());
    if (numbersAll) {
      return Optional.empty();
    }
    return Optional.of(point + " must be a point, numbers all");
  }

  /** Whether it has no mass: none given. */
  public boolean isMassless() {
    return mass.in(Kilograms) == 0;
  }

  /**
   * A part's mass properties, from CAD's mass-properties report or a scale: {@code
   * MassProperties.of(Pounds.of(6), new Translation3d(0.3, 0, 0), Inertia.box(...))}.
   *
   * @param mass how much it weighs: zero when nobody knows
   * @param cg its center of mass, in its frame, in meters
   * @param inertia how hard it is to turn, about its center of mass, along its frame's axes
   */
  public static MassProperties of(Mass mass, Translation3d cg, Inertia inertia) {
    return builder().mass(mass).cg(cg).inertia(inertia).build();
  }

  /** Starts describing a part's mass properties, one named value at a time. */
  static MassPropertiesBuilder.MassStage builder() {
    return MassPropertiesBuilder.builder();
  }

  /**
   * The same part, seen from another frame: given in a frame that sits at {@code frame} in the
   * other, as a link's are given in its joint's frame and the robot's are wanted.
   */
  public MassProperties transformedBy(Transform3d frame) {
    return builder()
        .mass(mass)
        .cg(cg.rotateBy(frame.getRotation()).plus(frame.getTranslation()))
        .inertia(inertia.rotated(frame.getRotation()))
        .build();
  }

  /**
   * Its inertia tensor about a point rather than its center of mass, row by row, by the
   * parallel-axis theorem. With d the offset from the point to the center of mass, moving the axes
   * there adds the mass times (|d|² on the diagonal, less d's own outer product) to the tensor:
   * m·(|d|²·1 - d dᵀ).
   */
  double[] tensorAbout(Translation3d point) {
    double kilograms = mass.in(Kilograms);
    double[] tensor = inertia.entries();
    double[] offset = {
      cg.getX() - point.getX(), cg.getY() - point.getY(), cg.getZ() - point.getZ()
    };
    double offsetSquared = offset[0] * offset[0] + offset[1] * offset[1] + offset[2] * offset[2];
    for (int row = 0; row < 3; row++) {
      for (int column = 0; column < 3; column++) {
        double onDiagonal = 0;
        if (row == column) {
          onDiagonal = offsetSquared;
        }
        tensor[Inertia.at(row, column)] += kilograms * (onDiagonal - offset[row] * offset[column]);
      }
    }
    return tensor;
  }

  /**
   * Parts given in one frame, as one: their masses summed, at their common center of mass. Parts
   * with no mass add nothing; if none has any, the sum has none ({@link #NONE}).
   *
   * @throws IllegalArgumentException if there are none
   */
  public static MassProperties sum(List<MassProperties> parts) {
    if (parts.isEmpty()) {
      throw new IllegalArgumentException("a sum of no parts has no mass");
    }
    // The common center of mass is the parts' centers, weighted by their masses.
    double totalKilograms = 0;
    Translation3d massTimesCenter = Translation3d.ZERO;
    for (MassProperties part : parts) {
      double kilograms = part.mass.in(Kilograms);
      totalKilograms += kilograms;
      massTimesCenter = massTimesCenter.plus(part.cg.times(kilograms));
    }
    if (totalKilograms == 0) {
      return NONE;
    }
    Translation3d center = massTimesCenter.div(totalKilograms);
    // Tensors about the same point add, so each part's is taken about the common center first.
    double[] tensor = new double[9];
    for (MassProperties part : parts) {
      double[] aboutCenter = part.tensorAbout(center);
      for (int entry = 0; entry < 9; entry++) {
        tensor[entry] += aboutCenter[entry];
      }
    }
    return builder()
        .mass(Kilograms.of(totalKilograms))
        .cg(center)
        .inertia(Inertia.of(tensor))
        .build();
  }

  /**
   * What's left once a part, given in the same frame, is taken away: a robot as weighed, less its
   * mechanisms' links, is its chassis.
   *
   * @throws IllegalArgumentException naming what isn't a body's, if what's left has no mass, or
   *     turns more easily than any body could
   */
  public MassProperties minus(MassProperties part) {
    double kilogramsLeft = mass.in(Kilograms) - part.mass.in(Kilograms);
    if (!(kilogramsLeft > 0)) {
      throw new IllegalArgumentException(
          "nothing is left: " + shown(part.mass) + " taken from " + shown(mass));
    }
    // The reverse of a sum: what is left is centered where the whole's mass times its center,
    // less the part's, puts it, and its tensor is the whole's less the part's, both taken about
    // that center.
    Translation3d wholeMassTimesCenter = cg.times(mass.in(Kilograms));
    Translation3d partMassTimesCenter = part.cg.times(part.mass.in(Kilograms));
    Translation3d center = wholeMassTimesCenter.minus(partMassTimesCenter).div(kilogramsLeft);
    double[] tensor = tensorAbout(center);
    double[] partsTensor = part.tensorAbout(center);
    for (int entry = 0; entry < 9; entry++) {
      tensor[entry] -= partsTensor[entry];
    }
    return builder()
        .mass(Kilograms.of(kilogramsLeft))
        .cg(center)
        .inertia(Inertia.of(tensor))
        .build();
  }
}
