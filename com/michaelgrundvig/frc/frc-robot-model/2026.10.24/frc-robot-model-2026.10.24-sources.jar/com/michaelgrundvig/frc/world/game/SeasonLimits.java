package com.michaelgrundvig.frc.world.game;

import static com.michaelgrundvig.frc.world.config.Rules.nonNegative;
import static com.michaelgrundvig.frc.world.config.Rules.positive;
import static com.michaelgrundvig.frc.world.config.Rules.shown;
import static org.wpilib.units.Units.Kilograms;
import static org.wpilib.units.Units.Meters;

import com.michaelgrundvig.frc.world.config.Checks;
import com.michaelgrundvig.frc.world.config.ConfigRecord;
import com.michaelgrundvig.frc.world.robot.Body;
import com.michaelgrundvig.frc.world.robot.Condition;
import com.michaelgrundvig.frc.world.robot.Configuration;
import com.michaelgrundvig.frc.world.robot.Joint;
import com.michaelgrundvig.frc.world.robot.RobotDefinition;
import com.michaelgrundvig.frc.world.robot.RobotMath;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import org.wpilib.units.measure.Distance;
import org.wpilib.units.measure.Mass;

/**
 * What a season's game manual allows a robot to be: how big around, how tall at the start, how far
 * it may reach out, where its bumpers go, and how much it may weigh. The season's game class holds
 * its numbers; every robot's definition is checked against them in the tests ({@link #problems}),
 * its named configurations too. Where the robot reaches between its configurations, mid-move, isn't
 * checked: no guard reads the limits while the robot runs.
 *
 * @param framePerimeter the most the frame may measure around
 * @param startingHeight the tallest the robot may be in its starting configuration: every joint
 *     where it rests
 * @param extension the farthest any part may reach beyond the frame perimeter, seen from above
 * @param bumperZoneBottom the lowest the bumpers may sit, above the floor: the floor itself, in a
 *     season whose zone starts there
 * @param bumperZoneTop the highest they may reach
 * @param weight the most the robot may weigh, bumpers on and battery off
 * @param battery the battery's mass, with its leads: what the weight leaves out of a robot weighed
 *     with it
 */
@ConfigRecord
public record SeasonLimits(
    Distance framePerimeter,
    Distance startingHeight,
    Distance extension,
    Distance bumperZoneBottom,
    Distance bumperZoneTop,
    Mass weight,
    Mass battery) {
  public SeasonLimits {
    Checks.on(SeasonLimits.class)
        .field("framePerimeter", framePerimeter, positive())
        .field("startingHeight", startingHeight, positive())
        .field("extension", extension, positive())
        .field("bumperZoneBottom", bumperZoneBottom, nonNegative())
        .field("bumperZoneTop", bumperZoneTop, positive())
        .field("weight", weight, positive())
        .field("battery", battery, positive())
        .whyNot("bumperZoneTop", () -> whyNotAZone(bumperZoneBottom, bumperZoneTop))
        .orThrow();
  }

  /** Why two heights are no bumper zone, if they are not: its top has to be above its bottom. */
  private static Optional<String> whyNotAZone(Distance bottom, Distance top) {
    if (top.gt(bottom)) {
      return Optional.empty();
    }
    return Optional.of(shown(top) + " must be above the zone's bottom (" + shown(bottom) + ")");
  }

  /**
   * How far past a limit still counts as at it: a robot built to a limit exactly, in inches or
   * pounds, mustn't fail by the rounding of its conversion to meters or kilograms.
   */
  private static final double SLACK = 1e-9;

  /**
   * The most the season allows a robot to weigh with its battery in, in the rule's own unit: what a
   * robot not weighed yet is taken to weigh ({@link #robotMass}).
   */
  public Mass maximumWithBattery() {
    return weight.unit().of(weight.plus(battery).in(weight.unit()));
  }

  /**
   * The robot's mass, bumpers and battery on, as everything that needs one takes it: as weighed
   * ({@code Body.weight}), or until it is, the most the season allows ({@link
   * #maximumWithBattery}), which the robot's missing-data report says. The one place a robot's mass
   * is settled: the program that runs a robot on the season's field asks it once.
   */
  public Mass robotMass(Body body) {
    return body.weight().orElseGet(this::maximumWithBattery);
  }

  /** Starts describing a season's limits, one named value at a time. */
  public static SeasonLimitsBuilder.FramePerimeterStage builder() {
    return SeasonLimitsBuilder.builder();
  }

  /**
   * Everything about a robot's definition the rules don't allow, each in words; empty when it fits.
   * The robot is checked as it starts a match, every joint where it rests, and in each of its
   * configurations, the joints it doesn't name where they rest, against the extension limit. Only
   * the links with shapes reach anywhere; collisions between links aren't checked yet. A robot
   * that's weighed is checked against the weight limit; one that isn't yet is taken at the most the
   * season allows, and its mass checked to add up at that ({@code RobotDefinition.massProblems}),
   * as the definition checks a given weight's itself.
   */
  public List<String> problems(RobotDefinition definition) {
    Body body = definition.body();
    RobotMath math = definition.math();
    Map<Joint, Double> atRest = math.rests();
    List<Optional<String>> found = new ArrayList<>();
    found.add(whyFrameIsTooBig(body));
    found.add(whyItStartsTooTall(body, math.top(atRest)));
    found.add(whyItStartsOutsideItsFrame(math.extension(atRest)));
    for (Configuration configuration : definition.configurations()) {
      double reach = math.extension(positions(configuration));
      found.add(whyItReachesTooFar(configuration, reach));
    }
    found.add(whyBumpersAreOutOfTheirZone(body));
    found.add(body.weight().flatMap(this::whyItIsTooHeavy));
    List<String> problems = new ArrayList<>(found.stream().flatMap(Optional::stream).toList());
    if (body.weight().isEmpty()) {
      problems.addAll(definition.massProblems(maximumWithBattery()));
    }
    return problems;
  }

  private Optional<String> whyFrameIsTooBig(Body body) {
    boolean tooBig = body.framePerimeter().in(Meters) > framePerimeter.in(Meters) + SLACK;
    if (!tooBig) {
      return Optional.empty();
    }
    return Optional.of(
        "its frame is "
            + shown(body.framePerimeter())
            + " around, more than the "
            + shown(framePerimeter)
            + " allowed");
  }

  /**
   * @param topOfLinks how high the highest point of any link is as the robot starts, in meters
   */
  private Optional<String> whyItStartsTooTall(Body body, double topOfLinks) {
    double tallest = Math.max(body.overallHeight().in(Meters), topOfLinks);
    boolean tooTall = tallest > startingHeight.in(Meters) + SLACK;
    if (!tooTall) {
      return Optional.empty();
    }
    return Optional.of(
        String.format(
            Locale.ROOT,
            "it starts %.3f m tall, more than the %.3f m allowed",
            tallest,
            startingHeight.in(Meters)));
  }

  /**
   * @param reachAtStart how far any link reaches beyond the frame perimeter as the robot starts, in
   *     meters
   */
  private static Optional<String> whyItStartsOutsideItsFrame(double reachAtStart) {
    boolean startsOutside = reachAtStart > SLACK;
    if (!startsOutside) {
      return Optional.empty();
    }
    return Optional.of(
        String.format(
            Locale.ROOT,
            "it starts reaching %.3f m beyond its frame perimeter: it must start inside it",
            reachAtStart));
  }

  /**
   * @param reach how far any link reaches beyond the frame perimeter in the configuration, in
   *     meters
   */
  private Optional<String> whyItReachesTooFar(Configuration configuration, double reach) {
    boolean tooFar = reach > extension.in(Meters) + SLACK;
    if (!tooFar) {
      return Optional.empty();
    }
    return Optional.of(
        String.format(
            Locale.ROOT,
            "configuration %s reaches %.3f m beyond its frame perimeter, more than the %.3f m"
                + " allowed",
            configuration.name(),
            reach,
            extension.in(Meters)));
  }

  private Optional<String> whyBumpersAreOutOfTheirZone(Body body) {
    boolean tooLow = body.bumperBottom().in(Meters) < bumperZoneBottom.in(Meters) - SLACK;
    boolean tooHigh = body.bumperTop().in(Meters) > bumperZoneTop.in(Meters) + SLACK;
    if (!tooLow && !tooHigh) {
      return Optional.empty();
    }
    return Optional.of(
        "its bumpers, "
            + shown(body.bumperBottom())
            + " to "
            + shown(body.bumperTop())
            + " up, aren't within the bumper zone, "
            + shown(bumperZoneBottom)
            + " to "
            + shown(bumperZoneTop));
  }

  /**
   * The robot's weight is given with its battery in, and the rule weighs it with the battery out,
   * so the battery's mass is taken off first.
   */
  private Optional<String> whyItIsTooHeavy(Mass weighed) {
    Mass withoutBattery = weighed.minus(battery);
    boolean tooHeavy = withoutBattery.in(Kilograms) > weight.in(Kilograms) + SLACK;
    if (!tooHeavy) {
      return Optional.empty();
    }
    // In the rule's own unit, as the rule book says it: 135 lb, not a mix of it and kilograms.
    Mass inTheRulesUnit = weight.unit().of(withoutBattery.in(weight.unit()));
    return Optional.of(
        "it weighs "
            + shown(inTheRulesUnit)
            + " without its battery, more than the "
            + shown(weight)
            + " allowed: lighten it, or weigh it again");
  }

  /**
   * Where a configuration puts the joints it names at positions; the rest stay where they rest, and
   * its outputs move nothing anywhere.
   */
  private static Map<Joint, Double> positions(Configuration configuration) {
    Map<Joint, Double> positions = new LinkedHashMap<>();
    for (Condition.At target : configuration.targets()) {
      if (!target.isOutput()) {
        positions.put(target.joint(), target.joint().position(target.name()).value());
      }
    }
    return positions;
  }
}
