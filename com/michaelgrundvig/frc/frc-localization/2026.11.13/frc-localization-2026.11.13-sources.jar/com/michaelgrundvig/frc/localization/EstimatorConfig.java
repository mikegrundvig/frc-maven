package com.michaelgrundvig.frc.localization;

import static com.michaelgrundvig.frc.world.config.Rules.atLeast;
import static com.michaelgrundvig.frc.world.config.Rules.atMost;
import static com.michaelgrundvig.frc.world.config.Rules.below;
import static com.michaelgrundvig.frc.world.config.Rules.nonNegative;
import static com.michaelgrundvig.frc.world.config.Rules.positive;
import static com.michaelgrundvig.frc.world.config.Rules.shown;

import com.michaelgrundvig.frc.world.config.Checks;
import com.michaelgrundvig.frc.world.config.ConfigRecord;

/**
 * How the pose estimator weighs odometry, the gyro, and the cameras. The defaults are reasonable
 * starting points, not measurements: fit them from logged residuals (the calibration procedures),
 * never from one run.
 *
 * @param translationStdDevPerMeter how far odometry's position may be off after one meter of
 *     travel, in meters. Its variance grows with distance.
 * @param translationStdDevPerRadian how far odometry's position may be off after turning one
 *     radian, in meters: wheels scrub as they turn
 * @param residualScale how much of the wheels' disagreement (the kinematic residual, which says how
 *     far it may have put their travel off) counts as suspect travel: 1 counts all of it
 * @param tiltStartDegrees below this tilt the wheels are trusted fully
 * @param tiltZeroDegrees at and above this tilt the wheels' travel counts for nothing: a robot
 *     climbing a bump or a ramp has wheels in the air (a top team scaled to zero at 25 degrees).
 *     Between the two, their travel counts for less, and the share left out counts as suspect.
 * @param groundSlopeMarginDegrees on known raised ground, a tilt up to this much steeper than its
 *     slopes is still the ground's (bumpers, suspension, and the IMU's mount), and the wheels stay
 *     trusted through it. The bump procedure measures it (docs/calibration.md, tilt on a bump).
 * @param slipCorrelationSeconds how long slip keeps its direction. Suspect travel within this time
 *     adds up before it's squared: a slip that builds one way for a quarter second grows the
 *     uncertainty as one error, not as many small ones that would average out.
 * @param collisionStdDevMeters how far a collision may have moved the robot beyond what its wheels
 *     saw: added at once, since the robot has already moved by the time the jolt is read
 * @param collisionWindowSeconds how long after a jolt the robot counts as just hit: more jolts
 *     within it are the same collision, and a scoring gate waits it out
 * @param handlingStdDevPerSqrtSecond while the robot is disabled, how far people may carry it where
 *     its wheels can't see, in meters after one second; the variance grows with time
 * @param headingDriftDegreesPerMinute how far the gyro's heading may drift in a minute
 * @param headingStdDevDegreesPerTurn how far the gyro's heading may be off after a full turn: its
 *     scale error, the same in every turn, so five turns are five times as far off. It is how
 *     unsure the estimator is of the gyro's scale before the cameras have said anything of it; the
 *     gyro-scale procedure measures the scale itself
 * @param gyroErrors whether the cameras may correct the gyro's scale and its drift as the robot
 *     drives, or the estimator only carries their doubt
 * @param gyroScaleWanderPercentPerMinute how far the gyro's scale may wander in a minute, in
 *     percent, so that an estimate of it never grows too sure to follow it: a MEMS gyro's scale
 *     moves a few hundredths of a percent for each degree Celsius its part warms, and a robot's
 *     electronics warm a degree or so a minute while it plays. It counts only where the gyro's
 *     errors are estimated.
 * @param gyroDriftStdDevDegreesPerMinute how fast the gyro may drift steadily, the same every
 *     second, before the cameras have said anything of it: what its calibration at rest left, or a
 *     robot that was moved while it calibrated. It counts only where the gyro's errors are
 *     estimated; {@code headingDriftDegreesPerMinute} is the drift that does not repeat. A robot
 *     standing still reads the drift off its gyro, each second of standing, and takes a stretch
 *     whose drift is past three times this for a robot being carried.
 * @param gyroDriftWanderDegreesPerMinute how far that steady drift may change in a minute, in
 *     degrees a minute, as the part warms
 * @param backupHeadingStdDevDegreesPerTurn the same for the backup IMU, while it turns odometry in
 *     the gyro's place: its own scale error, the same in every turn it makes, and unrelated to the
 *     gyro's (the gyro-scale procedure calibrates the gyro alone)
 * @param headingNoiseDegreesPerTurn how far an IMU's heading may be off at random after a full
 *     turn, beyond its scale: errors that don't repeat from turn to turn, whose variance grows with
 *     the turning
 * @param wheelHeadingStdDevDegreesPerTurn the same for heading from the wheels, used only while
 *     both IMUs are lost; its errors are taken as new with every turn
 * @param cameraShiftStdDevMeters how far each camera's positions may be off the same way image
 *     after image, beyond its mount, its turn and the tags', along the robot's forward and left, so
 *     it turns with the robot. How far the mount itself may be off is the camera's own ({@code
 *     CameraConfig.mountTolerance}), and adds to this. It stands in for a single tag's solve coming
 *     out short from noisy corners, which hangs on the tag's range and angle and is shared by every
 *     camera seeing it face-on: a stop-gap (docs/values.md).
 * @param cameraShiftStdDevDegrees and how far its headings may, beyond its turn: tags off the
 *     layout turn a multi-tag solve's heading by how far off they are over how far apart they sit
 * @param cameraWatchMeasurements how many of a camera's latest accepted measurements its mount and
 *     its clock are watched by: a camera whose measurements keep landing to one side of the other
 *     cameras', over about this many, has that taken off them and counts for less, and counts in
 *     full again once they stop. Enough that the noise of single images averages out well below
 *     what a calibrated mount is allowed (25 images' noise of 1 cm is 2 mm), and no more, so that a
 *     knocked camera is found within a second at 25 images a second.
 * @param cameraClockStdDevSeconds how late or early a camera's images may be stamped while its time
 *     sync works: a few milliseconds, for the sync itself and for where in its exposure an image
 *     counts as taken. The estimator finds a camera's lateness from how its measurements miss the
 *     other cameras' as the robot moves and turns, and takes off what that lateness puts them off
 *     by, where the lateness is past three times this.
 * @param tagPlacementStdDevMeters how far each tag may sit from where the field's layout says,
 *     along the field and across it (the field's tolerance, and how it was built): the same for
 *     every camera that sees it and every time it's seen, so the estimator keeps it apart for each
 *     tag, and a tag several cameras see counts once
 * @param cameraShiftCorrelationMeters how far the robot moves before what a camera's headings share
 *     is mostly new ({@code cameraShiftStdDevDegrees}): it sees other tags, or the same ones from
 *     elsewhere
 * @param cameraShiftCorrelationDegrees and how far it turns
 * @param historySeconds how far back a late camera measurement can still be applied at its capture
 *     time: at most {@value #MOST_HISTORY_SECONDS}
 * @param futureToleranceSeconds how far a measurement may be stamped after the newest odometry
 *     sample (clocks differ a little) before it's rejected
 * @param visionTimeoutSeconds how long without an accepted camera measurement before the estimate
 *     counts as dead reckoning
 * @param disagreementWindowSeconds how far back the health's vision-odometry disagreement looks
 * @param gateChiSquaredPosition the gate for a position measurement: its innovation's squared
 *     Mahalanobis distance may not exceed this (13.8 passes 99.9% of good measurements, 2 degrees
 *     of freedom)
 * @param gateChiSquaredPose the same for a measurement with heading (16.3: 99.9%, 3 degrees)
 * @param recoveryMeasurements how many rejected measurements must agree with each other, within the
 *     recovery window, before odometry is judged wrong and the estimate jumps to them. They must
 *     come from two cameras or two tags, or follow a sign that the robot was moved unseen (a jolt,
 *     a slide, a tilt, being disabled or placed): one camera repeating one tag's answer is one
 *     source however many times it says it
 * @param recoveryWindowSeconds how recent those rejected measurements must be
 * @param recoveryAgreementMeters how closely their innovations must agree
 * @param recoveryStdDevMeters the position uncertainty after a recovery
 * @param recoveryAgreementDegrees how closely rejected measurements' headings must agree before the
 *     gyro's heading is judged wrong (a bad heading reset, a robot placed backwards, a gyro that
 *     jumped) and the estimate turns to them; and how closely a camera's heading must agree with a
 *     driver's heading reset to back it
 * @param recoveryHeadingStdDevDegrees the heading uncertainty after a heading recovery
 * @param lostAfterRejections this many camera measurements rejected in a row, with none accepted
 *     between, and the estimate is lost: the cameras keep disagreeing with it
 * @param lostPositionStdDevMeters the position uncertainty after a heading recovery: the position
 *     was worked out with the wrong heading, so it could be far off
 */
@ConfigRecord
public record EstimatorConfig(
    double translationStdDevPerMeter,
    double translationStdDevPerRadian,
    double residualScale,
    double tiltStartDegrees,
    double tiltZeroDegrees,
    double groundSlopeMarginDegrees,
    double slipCorrelationSeconds,
    double collisionStdDevMeters,
    double collisionWindowSeconds,
    double handlingStdDevPerSqrtSecond,
    double headingDriftDegreesPerMinute,
    double headingStdDevDegreesPerTurn,
    GyroErrors gyroErrors,
    double gyroScaleWanderPercentPerMinute,
    double gyroDriftStdDevDegreesPerMinute,
    double gyroDriftWanderDegreesPerMinute,
    double backupHeadingStdDevDegreesPerTurn,
    double headingNoiseDegreesPerTurn,
    double wheelHeadingStdDevDegreesPerTurn,
    double cameraShiftStdDevMeters,
    double cameraShiftStdDevDegrees,
    int cameraWatchMeasurements,
    double cameraClockStdDevSeconds,
    double tagPlacementStdDevMeters,
    double cameraShiftCorrelationMeters,
    double cameraShiftCorrelationDegrees,
    double historySeconds,
    double futureToleranceSeconds,
    double visionTimeoutSeconds,
    double disagreementWindowSeconds,
    double gateChiSquaredPosition,
    double gateChiSquaredPose,
    int recoveryMeasurements,
    double recoveryWindowSeconds,
    double recoveryAgreementMeters,
    double recoveryStdDevMeters,
    double recoveryAgreementDegrees,
    double recoveryHeadingStdDevDegrees,
    int lostAfterRejections,
    double lostPositionStdDevMeters) {
  /**
   * The longest history the estimator keeps, in seconds. An image later than this is of a robot
   * meters from where it now is, and the history's memory grows with its length: at a thousand
   * steps a second, several megabytes a second of it.
   */
  public static final double MOST_HISTORY_SECONDS = 5;

  /** Starting points for a swerve robot with a good gyro. */
  public static EstimatorConfig defaults() {
    return builder()
        .translationStdDevPerMeter(0.03)
        .translationStdDevPerRadian(0.02)
        .residualScale(1.0)
        .tiltStartDegrees(5)
        .tiltZeroDegrees(25)
        .groundSlopeMarginDegrees(3)
        .slipCorrelationSeconds(0.5)
        .collisionStdDevMeters(0.25)
        .collisionWindowSeconds(0.25)
        .handlingStdDevPerSqrtSecond(0.02)
        .headingDriftDegreesPerMinute(0.5)
        .headingStdDevDegreesPerTurn(3.6)
        .gyroErrors(GyroErrors.ESTIMATED)
        .gyroScaleWanderPercentPerMinute(0.02)
        .gyroDriftStdDevDegreesPerMinute(5.0)
        .gyroDriftWanderDegreesPerMinute(0.1)
        .backupHeadingStdDevDegreesPerTurn(2.0)
        .headingNoiseDegreesPerTurn(0.1)
        .wheelHeadingStdDevDegreesPerTurn(10)
        .cameraShiftStdDevMeters(0.004)
        .cameraShiftStdDevDegrees(2.0)
        .cameraWatchMeasurements(25)
        .cameraClockStdDevSeconds(0.003)
        .tagPlacementStdDevMeters(0.01)
        .cameraShiftCorrelationMeters(1.0)
        .cameraShiftCorrelationDegrees(45)
        .historySeconds(1.5)
        .futureToleranceSeconds(0.05)
        .visionTimeoutSeconds(1.0)
        .disagreementWindowSeconds(0.5)
        .gateChiSquaredPosition(13.816)
        .gateChiSquaredPose(16.266)
        .recoveryMeasurements(3)
        .recoveryWindowSeconds(1.0)
        .recoveryAgreementMeters(0.25)
        .recoveryStdDevMeters(0.25)
        .recoveryAgreementDegrees(5)
        .recoveryHeadingStdDevDegrees(2)
        .lostAfterRejections(2)
        .lostPositionStdDevMeters(1.0)
        .build();
  }

  public EstimatorConfig {
    Checks.on(EstimatorConfig.class)
        .field("translationStdDevPerMeter", translationStdDevPerMeter, nonNegative())
        .field("translationStdDevPerRadian", translationStdDevPerRadian, nonNegative())
        .field("residualScale", residualScale, nonNegative())
        .field("tiltStartDegrees", tiltStartDegrees, nonNegative())
        .field("tiltZeroDegrees", tiltZeroDegrees, below(90))
        .field("groundSlopeMarginDegrees", groundSlopeMarginDegrees, nonNegative())
        .field("slipCorrelationSeconds", slipCorrelationSeconds, positive())
        .field("collisionStdDevMeters", collisionStdDevMeters, nonNegative())
        .field("collisionWindowSeconds", collisionWindowSeconds, positive())
        .field("handlingStdDevPerSqrtSecond", handlingStdDevPerSqrtSecond, nonNegative())
        .field("headingDriftDegreesPerMinute", headingDriftDegreesPerMinute, nonNegative())
        .field("headingStdDevDegreesPerTurn", headingStdDevDegreesPerTurn, nonNegative())
        .field("gyroScaleWanderPercentPerMinute", gyroScaleWanderPercentPerMinute, nonNegative())
        .field("gyroDriftStdDevDegreesPerMinute", gyroDriftStdDevDegreesPerMinute, nonNegative())
        .field("gyroDriftWanderDegreesPerMinute", gyroDriftWanderDegreesPerMinute, nonNegative())
        .field(
            "backupHeadingStdDevDegreesPerTurn", backupHeadingStdDevDegreesPerTurn, nonNegative())
        .field("headingNoiseDegreesPerTurn", headingNoiseDegreesPerTurn, nonNegative())
        .field("wheelHeadingStdDevDegreesPerTurn", wheelHeadingStdDevDegreesPerTurn, nonNegative())
        .field("cameraShiftStdDevMeters", cameraShiftStdDevMeters, nonNegative())
        .field("cameraShiftStdDevDegrees", cameraShiftStdDevDegrees, nonNegative())
        .field("cameraWatchMeasurements", cameraWatchMeasurements, atLeast(20))
        .field("cameraClockStdDevSeconds", cameraClockStdDevSeconds, positive())
        .field("tagPlacementStdDevMeters", tagPlacementStdDevMeters, nonNegative())
        .field("cameraShiftCorrelationMeters", cameraShiftCorrelationMeters, positive())
        .field("cameraShiftCorrelationDegrees", cameraShiftCorrelationDegrees, positive())
        .field("historySeconds", historySeconds, positive())
        .field("historySeconds", historySeconds, atMost(MOST_HISTORY_SECONDS))
        .field("futureToleranceSeconds", futureToleranceSeconds, nonNegative())
        .field("visionTimeoutSeconds", visionTimeoutSeconds, positive())
        .field("disagreementWindowSeconds", disagreementWindowSeconds, positive())
        .field("gateChiSquaredPosition", gateChiSquaredPosition, positive())
        .field("gateChiSquaredPose", gateChiSquaredPose, positive())
        .field("recoveryMeasurements", recoveryMeasurements, atLeast(2))
        .field("recoveryWindowSeconds", recoveryWindowSeconds, positive())
        .field("recoveryAgreementMeters", recoveryAgreementMeters, nonNegative())
        .field("recoveryStdDevMeters", recoveryStdDevMeters, positive())
        .field("recoveryAgreementDegrees", recoveryAgreementDegrees, positive())
        .field("recoveryHeadingStdDevDegrees", recoveryHeadingStdDevDegrees, positive())
        .field("lostAfterRejections", lostAfterRejections, atLeast(1))
        .field("lostPositionStdDevMeters", lostPositionStdDevMeters, positive())
        .check(
            "tiltZeroDegrees",
            () -> {
              if (tiltZeroDegrees > tiltStartDegrees) {
                return null;
              }
              return shown(tiltZeroDegrees)
                  + " must be above tiltStartDegrees ("
                  + shown(tiltStartDegrees)
                  + "): wheels stop counting above where they start to count less";
            })
        .orThrow();
  }

  /**
   * What the estimator does about the gyro's own errors: reading its turns a little large or small
   * (its scale), and turning a little every second while the robot stands still (its drift).
   */
  public enum GyroErrors {
    /**
     * It carries the scale's doubt ({@code headingStdDevDegreesPerTurn}) and never corrects it: the
     * heading grows less sure with every turn, by the same error each time, until a camera corrects
     * the heading itself. Drift is noise that grows the heading's doubt with time ({@code
     * headingDriftDegreesPerMinute}). Right for a gyro whose scale was measured and set, on a robot
     * whose cameras the team would rather not have touch the gyro.
     */
    CONSIDERED,
    /**
     * It estimates both: whatever corrects the heading also says, by how far the heading was off
     * after how much turning and how much time, how the gyro misreads its turns and how fast it
     * drifts, and every step after is corrected by that. A gyro a few percent off, or drifting some
     * degrees a minute, is followed within a few turns or seconds, and its heading then stays right
     * through a turn and through a stretch without tags. Both start from no error, as unsure as
     * {@code headingStdDevDegreesPerTurn} and {@code gyroDriftStdDevDegreesPerMinute} say.
     */
    ESTIMATED
  }

  /** Starts building estimator settings, one named value at a time. */
  public static EstimatorConfigBuilder.TranslationStdDevPerMeterStage builder() {
    return EstimatorConfigBuilder.builder();
  }
}
