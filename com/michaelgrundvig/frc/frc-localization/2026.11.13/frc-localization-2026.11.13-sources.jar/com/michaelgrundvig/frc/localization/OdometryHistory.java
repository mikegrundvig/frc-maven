package com.michaelgrundvig.frc.localization;

import java.util.Arrays;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.geometry.Translation2d;

/**
 * The pose estimator's memory of how the robot drove: its recent odometry steps, oldest first, each
 * kept with the filter's state as it was once that step had been applied.
 *
 * <p>The estimator needs it because a camera's image arrives late. To apply a measurement at the
 * moment its image was taken, the estimator puts the filter back as it was after the last step
 * before that moment ({@link #restore}), applies the measurement, and replays every step since.
 *
 * <p><b>Steps and slots.</b> Two kinds of number index this class, and they are easy to confuse. A
 * <em>step number</em> is what callers use: {@link #OLDEST_STEP} is the oldest step kept and {@link
 * #newestStep()} the latest, so a step's number goes down by one whenever an older step is dropped.
 * A <em>slot</em> is where a step's values sit in the arrays, which are used as a ring so that
 * dropping the oldest step moves nothing. Only {@link #slotOf} turns a step number into a slot, and
 * no slot ever leaves this class.
 *
 * <p>A step covers the stretch of time from the step before it to its own time. The oldest step
 * kept is only a starting point: its travel belongs to a stretch the history no longer holds, and
 * nothing reads it.
 *
 * <p>The values are kept in one array for each kind of value, not in an object for each step,
 * because a step is added at the odometry rate (250 Hz on a robot) and nothing may be allocated
 * there.
 */
final class OdometryHistory {
  /** The number of the oldest step kept. */
  static final int OLDEST_STEP = 0;

  /**
   * A rate at a step is taken over this many steps up to it: a loop's worth at 250 steps a second,
   * so that one step's rounding does not show.
   */
  private static final int RATE_STEPS = 5;

  /**
   * How the robot moved lately.
   *
   * @param fieldVelocity its velocity over the field, in meters a second
   * @param yawRateRadiansPerSecond how fast it turned, counterclockwise
   */
  record Motion(Translation2d fieldVelocity, double yawRateRadiansPerSecond) {
    /** A robot that has not moved, or a history too short to say how it did. */
    static final Motion NONE = new Motion(Translation2d.ZERO, 0);
  }

  /** How many steps it can keep now: it grows, up to {@link #mostCapacity}, if it must. */
  private int capacity;

  /** The most steps it ever keeps, before each new one drops the oldest. */
  private final int mostCapacity;

  /** The slot of the oldest step kept. */
  private int oldestSlot;

  /** How many steps are kept: at least one once {@link #start} has been called. */
  private int stepCount;

  // What each step was, fixed when it was added. Every array is indexed by slot.

  /** When each step ended, on the robot's clock. */
  private long[] endTimeNanos;

  /**
   * How far the wheels carried the robot over each step, forward and to the left in the robot's
   * frame as the step began, with whatever the estimator discounted for a tilt already taken off.
   */
  private double[] travelForwardMeters;

  private double[] travelLeftMeters;

  /** How far the wheels' disagreement with each other may have put each step's travel off. */
  private double[] wheelResidualMeters;

  /**
   * The position variance each step adds beyond what its distance and turning add, for slip, tilt
   * and collisions. It is worked out when the step arrives and kept, so a replay weighs the step
   * exactly as it was first weighed.
   */
  private double[] addedPositionVariance;

  /** What turned the robot over each step: an IMU, or the wheels standing in for one. */
  private YawSource[] turnedBy;

  /** The unwrapped yaw as each step ended, in radians. */
  private double[] yawAfterRadians;

  /**
   * How far the gyro had turned the robot, in all, as each step ended, in radians: the sum of the
   * turns of the steps the gyro turned, counted from when the history started. The gyro's scale
   * error misreads a share of exactly this, so the difference between two steps' sums is what the
   * scale has to say about the heading between them.
   */
  private double[] gyroTurnAfterRadians;

  /**
   * For how long the gyro had turned the robot, in all, as each step ended, in seconds: the sum of
   * the durations of the steps the gyro turned. The gyro's drift adds to the heading over exactly
   * this.
   */
  private double[] gyroSecondsAfter;

  /**
   * The gyro's drift as a stretch of standing still that ended with each step read it, in radians a
   * second, and that reading's variance ({@link GyroAtRest}). Not a number for a step no such
   * stretch ended with, which is nearly every one.
   */
  private double[] driftSeenAtRest;

  private double[] driftSeenVariance;

  /**
   * How far each camera's turn on its mount was opened up again as each step ended, as the variance
   * added to it ({@link PoseFilter#reopenCameraTurn}), in radians squared: its mount may have been
   * knocked. {@link ConsideredErrors#MAX_CAMERAS} for each step, by the camera's place, and zero
   * for nearly every one.
   */
  private double[] turnReopenedBy;

  /**
   * How far the wheels and the gyro alone had carried the robot over the field, in all, as each
   * step ended, in meters along x and along y: the sum of every step's move as the filter first
   * predicted it, counted from when the history started. No camera's correction is in it, so the
   * difference between two steps' sums is how the robot moved between them by odometry alone.
   */
  private double[] carriedXAfter;

  private double[] carriedYAfter;

  /**
   * How unsure odometry alone had become of where the robot is, in all, as each step ended, as a
   * variance along each axis: the sum of the position variance every step added, for its distance,
   * its turning, and whatever made its wheels suspect, counted from when the history started.
   */
  private double[] carriedVarianceAfter;

  // The filter's state once each step had been applied. A replay rewrites these.

  private double[] filterXAfter;
  private double[] filterYAfter;
  private double[] filterHeadingOffsetAfter;
  private double[] filterGyroScaleAfter;
  private double[] filterGyroDriftAfter;

  /**
   * The filter's uncertainty after each step, one step after another: for each slot, the {@link
   * #uncertaintyLength} numbers that {@link PoseFilter#copyUncertaintyTo} writes.
   */
  private double[] filterUncertaintyAfter;

  private final int uncertaintyLength;

  /**
   * A history that keeps up to a number of steps from the start.
   *
   * @param capacity how many steps it keeps before each new one drops the oldest
   * @param uncertaintyLength how many numbers the filter's uncertainty takes to store ({@link
   *     PoseFilter#uncertaintyLength()})
   */
  OdometryHistory(int capacity, int uncertaintyLength) {
    this(capacity, capacity, uncertaintyLength);
  }

  /**
   * A history with room for some steps at first, which grows if it must.
   *
   * <p>The filter's uncertainty is most of what each step keeps, thousands of numbers, so room for
   * steps that never come costs megabytes. The history starts with room for as many steps as the
   * usual odometry rate brings within its time, and doubles its room, up to the most, only if
   * odometry runs faster. Growing allocates, once for each doubling; nothing else does.
   *
   * @param capacity how many steps it has room for at first
   * @param mostCapacity the most steps it ever keeps, before each new one drops the oldest
   * @param uncertaintyLength how many numbers the filter's uncertainty takes to store ({@link
   *     PoseFilter#uncertaintyLength()})
   */
  OdometryHistory(int capacity, int mostCapacity, int uncertaintyLength) {
    if (capacity < 2 || mostCapacity < capacity) {
      throw new IllegalArgumentException(
          "room for at least two steps, and no more at first than at most: "
              + capacity
              + ", "
              + mostCapacity);
    }
    this.capacity = capacity;
    this.mostCapacity = mostCapacity;
    this.uncertaintyLength = uncertaintyLength;
    endTimeNanos = new long[capacity];
    travelForwardMeters = new double[capacity];
    travelLeftMeters = new double[capacity];
    wheelResidualMeters = new double[capacity];
    addedPositionVariance = new double[capacity];
    turnedBy = new YawSource[capacity];
    yawAfterRadians = new double[capacity];
    gyroTurnAfterRadians = new double[capacity];
    gyroSecondsAfter = new double[capacity];
    driftSeenAtRest = new double[capacity];
    driftSeenVariance = new double[capacity];
    turnReopenedBy = new double[capacity * ConsideredErrors.MAX_CAMERAS];
    carriedXAfter = new double[capacity];
    carriedYAfter = new double[capacity];
    carriedVarianceAfter = new double[capacity];
    filterXAfter = new double[capacity];
    filterYAfter = new double[capacity];
    filterHeadingOffsetAfter = new double[capacity];
    filterGyroScaleAfter = new double[capacity];
    filterGyroDriftAfter = new double[capacity];
    filterUncertaintyAfter = new double[capacity * uncertaintyLength];
  }

  /**
   * Starts the history over with a single step, the moment odometry starts from. That step has no
   * travel: it only says when the robot was first read and what its yaw was then.
   */
  void start(long timestampNanos, YawSource source, double yawRadians) {
    oldestSlot = 0;
    stepCount = 1;
    endTimeNanos[oldestSlot] = timestampNanos;
    turnedBy[oldestSlot] = source;
    yawAfterRadians[oldestSlot] = yawRadians;
    gyroTurnAfterRadians[oldestSlot] = 0;
    gyroSecondsAfter[oldestSlot] = 0;
    carriedXAfter[oldestSlot] = 0;
    carriedYAfter[oldestSlot] = 0;
    carriedVarianceAfter[oldestSlot] = 0;
    Arrays.fill(
        turnReopenedBy,
        oldestSlot * ConsideredErrors.MAX_CAMERAS,
        (oldestSlot + 1) * ConsideredErrors.MAX_CAMERAS,
        0);
  }

  /**
   * Adds the newest step. When the history is full, the oldest step is dropped to make room, and
   * every remaining step's number goes down by one.
   *
   * @param timestampNanos when the step ended
   * @param forwardMeters how far the wheels carried the robot forward, as much of it as counts
   * @param leftMeters and to the left
   * @param residualMeters how far the wheels' disagreement may have put that travel off
   * @param positionVariance the position variance the step adds for slip, tilt and collisions
   * @param source what turned the robot over this step: an IMU, or the wheels standing in
   * @param yawRadians the unwrapped yaw as the step ended
   * @return the new step's number, which is the newest
   */
  int add(
      long timestampNanos,
      double forwardMeters,
      double leftMeters,
      double residualMeters,
      double positionVariance,
      YawSource source,
      double yawRadians) {
    if (stepCount == capacity) {
      if (capacity < mostCapacity) {
        grow();
      } else {
        dropOldestStep();
      }
    }
    int previous = slotOf(newestStep());
    boolean gyroTurnedIt = source == YawSource.GYRO;
    double gyroTurn = gyroTurnedIt ? yawRadians - yawAfterRadians[previous] : 0;
    double gyroSeconds =
        gyroTurnedIt ? Timestamps.toSeconds(timestampNanos - endTimeNanos[previous]) : 0;
    stepCount++;
    int slot = slotOf(newestStep());
    endTimeNanos[slot] = timestampNanos;
    travelForwardMeters[slot] = forwardMeters;
    travelLeftMeters[slot] = leftMeters;
    wheelResidualMeters[slot] = residualMeters;
    addedPositionVariance[slot] = positionVariance;
    turnedBy[slot] = source;
    yawAfterRadians[slot] = yawRadians;
    gyroTurnAfterRadians[slot] = gyroTurnAfterRadians[previous] + gyroTurn;
    gyroSecondsAfter[slot] = gyroSecondsAfter[previous] + gyroSeconds;
    driftSeenAtRest[slot] = Double.NaN;
    Arrays.fill(
        turnReopenedBy,
        slot * ConsideredErrors.MAX_CAMERAS,
        (slot + 1) * ConsideredErrors.MAX_CAMERAS,
        0);
    return newestStep();
  }

  /**
   * Notes that a stretch of standing still ended with the newest step, and what it read of the
   * gyro's drift, so a replay corrects the drift by it again at the same step.
   */
  void sawDriftOverNewestStep(double radiansPerSecond, double variance) {
    int slot = slotOf(newestStep());
    driftSeenAtRest[slot] = radiansPerSecond;
    driftSeenVariance[slot] = variance;
  }

  /**
   * The gyro's drift as a stretch of standing still that ended with a step read it, in radians a
   * second, or not a number where none did.
   */
  double driftSeenAtRest(int step) {
    return driftSeenAtRest[slotOf(step)];
  }

  /** That reading's variance, in (radians a second) squared. */
  double driftSeenVariance(int step) {
    return driftSeenVariance[slotOf(step)];
  }

  /**
   * Notes that a camera's turn was opened up again as the newest step ended, so a replay opens it
   * again at the same step, by as much.
   *
   * @param camera the camera's place
   * @param variance the variance added to its turn, in radians squared
   */
  void reopenedTurnAtNewestStep(int camera, double variance) {
    turnReopenedBy[slotOf(newestStep()) * ConsideredErrors.MAX_CAMERAS + camera] += variance;
  }

  /** How far a camera's turn was opened up again as a step ended: zero if it was not. */
  double turnReopenedBy(int step, int camera) {
    return turnReopenedBy[slotOf(step) * ConsideredErrors.MAX_CAMERAS + camera];
  }

  /**
   * Notes how far the filter's prediction moved the robot over the newest step, on the field, as
   * the step was first predicted through: what the wheels and the gyro alone say of it, and the
   * position variance the step adds.
   */
  void movedOverNewestStep(double xMeters, double yMeters, double positionVariance) {
    int slot = slotOf(newestStep());
    int previous = slotOf(newestStep() - 1);
    carriedXAfter[slot] = carriedXAfter[previous] + xMeters;
    carriedYAfter[slot] = carriedYAfter[previous] + yMeters;
    carriedVarianceAfter[slot] = carriedVarianceAfter[previous] + positionVariance;
  }

  /**
   * How unsure where odometry alone has the robot is as a step ends ({@link #xByOdometryAlone}), as
   * a variance along each axis, in square meters: what the steps since the oldest kept have added.
   * The estimate's own doubt at the oldest step is left out: every camera's measurement is set
   * against the same place, so that part is the same in all of them.
   */
  double varianceByOdometryAlone(int step) {
    return carriedVarianceAfter[slotOf(step)] - carriedVarianceAfter[slotOf(OLDEST_STEP)];
  }

  /**
   * Where the robot would be part of the way through a step, along the field's x, had nothing but
   * the wheels and the gyro moved the estimate since the oldest step kept: the filter's position as
   * it was stored for the oldest step, carried on by odometry alone. It is what a camera's
   * measurement is set against to see whether the camera, and not the estimate, has moved ({@link
   * CameraWatch}).
   *
   * @param fraction how far through the step: 0 as it begins, 1 as it ends
   */
  double xByOdometryAlone(int step, double fraction) {
    return filterXAfter[slotOf(OLDEST_STEP)] + carriedSince(carriedXAfter, step, fraction);
  }

  /** The same along y. */
  double yByOdometryAlone(int step, double fraction) {
    return filterYAfter[slotOf(OLDEST_STEP)] + carriedSince(carriedYAfter, step, fraction);
  }

  /**
   * How fast odometry alone had the robot moving along the field's x as a step ended, in meters a
   * second: its move over the few steps up to that one, over the time they took. Zero at the oldest
   * step, which has no step before it to measure from.
   */
  double velocityX(int step) {
    return ratePerSecond(carriedXAfter, step);
  }

  /** The same along y. */
  double velocityY(int step) {
    return ratePerSecond(carriedYAfter, step);
  }

  /** How fast the yaw was turning as a step ended, counterclockwise, in radians a second. */
  double yawRate(int step) {
    return ratePerSecond(yawAfterRadians, step);
  }

  /**
   * How fast a value that is kept for each step was changing as a step ended, for each second: its
   * change over the last {@link #RATE_STEPS} steps up to that one, or as many as are kept.
   */
  private double ratePerSecond(double[] valueAfter, int step) {
    int from = Math.max(OLDEST_STEP, step - RATE_STEPS);
    double seconds = Timestamps.toSeconds(endTime(step) - endTime(from));
    if (seconds <= 0) {
      return 0;
    }
    return (valueAfter[slotOf(step)] - valueAfter[slotOf(from)]) / seconds;
  }

  /**
   * How far odometry alone carried the robot from the oldest step to part of the way through one.
   */
  private double carriedSince(double[] carriedAfter, int step, double fraction) {
    double atOldest = carriedAfter[slotOf(OLDEST_STEP)];
    if (step == OLDEST_STEP) {
      return 0;
    }
    double before = carriedAfter[slotOf(step - 1)];
    double after = carriedAfter[slotOf(step)];
    return before + fraction * (after - before) - atOldest;
  }

  /** How many steps are kept. Their numbers run from {@link #OLDEST_STEP} to this less one. */
  int stepCount() {
    return stepCount;
  }

  /** The number of the latest step. */
  int newestStep() {
    return stepCount - 1;
  }

  /** When a step ended. */
  long endTime(int step) {
    return endTimeNanos[slotOf(step)];
  }

  long oldestTime() {
    return endTime(OLDEST_STEP);
  }

  long newestTime() {
    return endTime(newestStep());
  }

  /** How long a step lasted: from the end of the step before it to its own end. */
  long durationNanos(int step) {
    return endTime(step) - endTime(step - 1);
  }

  double travelForward(int step) {
    return travelForwardMeters[slotOf(step)];
  }

  double travelLeft(int step) {
    return travelLeftMeters[slotOf(step)];
  }

  double wheelResidual(int step) {
    return wheelResidualMeters[slotOf(step)];
  }

  double addedPositionVariance(int step) {
    return addedPositionVariance[slotOf(step)];
  }

  YawSource turnedBy(int step) {
    return turnedBy[slotOf(step)];
  }

  /** The unwrapped yaw as a step ended. */
  double yawAfter(int step) {
    return yawAfterRadians[slotOf(step)];
  }

  /** How far the robot turned over a step. */
  double turnOver(int step) {
    return yawAfter(step) - yawAfter(step - 1);
  }

  /**
   * The yaw part of the way through a step, taking the robot to have turned evenly over it.
   *
   * @param fraction how far through the step: 0 as it begins, 1 as it ends
   */
  double yawPartWayThrough(int step, double fraction) {
    double yawBefore = yawAfter(step - 1);
    return yawBefore + fraction * (yawAfter(step) - yawBefore);
  }

  /** The last step that ended before a moment, or the oldest step if none did. */
  int lastStepBefore(long timestampNanos) {
    int step = newestStep();
    while (step > OLDEST_STEP && endTime(step) >= timestampNanos) {
      step--;
    }
    return step;
  }

  /** Keeps the filter's state as it is now, as its state after a step. */
  void store(int step, PoseFilter filter) {
    int slot = slotOf(step);
    filterXAfter[slot] = filter.x();
    filterYAfter[slot] = filter.y();
    filterHeadingOffsetAfter[slot] = filter.headingOffset();
    filterGyroScaleAfter[slot] = filter.gyroScale();
    filterGyroDriftAfter[slot] = filter.gyroDrift();
    filter.copyUncertaintyTo(filterUncertaintyAfter, slot * uncertaintyLength);
  }

  /** Puts the filter back in the state it was in after a step. */
  void restore(int step, PoseFilter filter) {
    int slot = slotOf(step);
    filter.restore(
        filterXAfter[slot],
        filterYAfter[slot],
        filterHeadingOffsetAfter[slot],
        filterGyroScaleAfter[slot],
        filterGyroDriftAfter[slot],
        filterUncertaintyAfter,
        slot * uncertaintyLength);
  }

  /** Drops every step but the newest, which becomes the oldest: the history starts from it. */
  void keepOnlyNewest() {
    oldestSlot = slotOf(newestStep());
    stepCount = 1;
  }

  /**
   * Drops the steps that are no longer needed to reach back to a moment. The oldest step is the
   * starting point for everything after it, so it can go only once the step after it ended at or
   * before that moment and can be the starting point instead. The newest step is always kept.
   */
  void dropStepsNotNeededSince(long cutoffNanos) {
    int secondOldest = OLDEST_STEP + 1;
    while (stepCount > 1 && endTime(secondOldest) <= cutoffNanos) {
      dropOldestStep();
    }
  }

  /**
   * Where the robot was at a moment between the oldest step and the newest, as the stored filter
   * states have it. The position is taken along a straight line between the states either side of
   * the moment, and the yaw likewise.
   *
   * <p>The heading then is the yaw then plus the heading offset then. The offset is given as the
   * estimate understands it today: today's offset, less what the gyro's errors have added to it
   * since, which is the scale times how far the gyro has turned the robot from that moment to now,
   * and the drift times for how long.
   *
   * @param headingOffsetRadians the filter's heading offset now
   * @param gyroScale the filter's estimate of the gyro's scale error now
   * @param gyroDrift and of its drift
   */
  Pose2d poseAt(
      long timestampNanos, double headingOffsetRadians, double gyroScale, double gyroDrift) {
    int newest = slotOf(newestStep());
    double gyroTurnNow = gyroTurnAfterRadians[newest];
    double gyroSecondsNow = gyroSecondsAfter[newest];
    // The step the moment falls in is the earliest one whose predecessor ended before the moment.
    int step = newestStep();
    while (step > OLDEST_STEP && endTime(step - 1) >= timestampNanos) {
      step--;
    }
    if (step == OLDEST_STEP) {
      int slot = slotOf(OLDEST_STEP);
      double offsetThen =
          headingOffsetRadians
              - gyroScale * (gyroTurnNow - gyroTurnAfterRadians[slot])
              - gyroDrift * (gyroSecondsNow - gyroSecondsAfter[slot]);
      return new Pose2d(
          filterXAfter[slot],
          filterYAfter[slot],
          new Rotation2d(yawAfterRadians[slot] + offsetThen));
    }
    int before = slotOf(step - 1);
    int after = slotOf(step);
    double fraction =
        (double) (timestampNanos - endTimeNanos[before])
            / (endTimeNanos[after] - endTimeNanos[before]);
    double gyroTurnThen =
        gyroTurnAfterRadians[before]
            + fraction * (gyroTurnAfterRadians[after] - gyroTurnAfterRadians[before]);
    double gyroSecondsThen =
        gyroSecondsAfter[before] + fraction * (gyroSecondsAfter[after] - gyroSecondsAfter[before]);
    double offsetThen =
        headingOffsetRadians
            - gyroScale * (gyroTurnNow - gyroTurnThen)
            - gyroDrift * (gyroSecondsNow - gyroSecondsThen);
    return new Pose2d(
        filterXAfter[before] + fraction * (filterXAfter[after] - filterXAfter[before]),
        filterYAfter[before] + fraction * (filterYAfter[after] - filterYAfter[before]),
        new Rotation2d(yawPartWayThrough(step, fraction) + offsetThen));
  }

  /**
   * How the robot moved over the latest steps: those that ended within a window of time before the
   * newest. Each step's travel is turned onto the field by the heading the robot had as the step
   * began, and the total is divided by the time those steps took.
   *
   * @param headingOffsetRadians the filter's heading offset, which makes a yaw a field heading.
   *     Today's offset is used for every step of the window: over a tenth of a second the gyro's
   *     scale changes it by too little to matter to a velocity's direction.
   */
  Motion motionOver(long windowNanos, double headingOffsetRadians) {
    long newestTime = newestTime();
    long windowStart = newestTime - windowNanos;
    double movedXMeters = 0;
    double movedYMeters = 0;
    double turnedRadians = 0;
    long earliestTime = newestTime;
    for (int step = newestStep(); step > OLDEST_STEP && endTime(step) > windowStart; step--) {
      int slot = slotOf(step);
      int previous = slotOf(step - 1);
      double heading = yawAfterRadians[previous] + headingOffsetRadians;
      double forward = travelForwardMeters[slot];
      double left = travelLeftMeters[slot];
      movedXMeters += Math.cos(heading) * forward - Math.sin(heading) * left;
      movedYMeters += Math.sin(heading) * forward + Math.cos(heading) * left;
      turnedRadians += yawAfterRadians[slot] - yawAfterRadians[previous];
      earliestTime = endTimeNanos[previous];
    }
    double seconds = Timestamps.toSeconds(newestTime - earliestTime);
    boolean anyTimePassed = seconds > 0;
    if (!anyTimePassed) {
      return Motion.NONE;
    }
    return new Motion(
        new Translation2d(movedXMeters / seconds, movedYMeters / seconds), turnedRadians / seconds);
  }

  private void dropOldestStep() {
    oldestSlot = slotOf(OLDEST_STEP + 1);
    stepCount--;
  }

  /** Where a step's values sit in the arrays. */
  private int slotOf(int step) {
    return (oldestSlot + step) % capacity;
  }

  /**
   * Doubles the room for steps, up to the most it keeps, with every step kept where it was in
   * order: the oldest moves to the first slot, and the rest follow it.
   */
  private void grow() {
    int grown = Math.min(2 * capacity, mostCapacity);
    endTimeNanos = grown(endTimeNanos, new long[grown], 1);
    travelForwardMeters = grown(travelForwardMeters, grown);
    travelLeftMeters = grown(travelLeftMeters, grown);
    wheelResidualMeters = grown(wheelResidualMeters, grown);
    addedPositionVariance = grown(addedPositionVariance, grown);
    turnedBy = grown(turnedBy, new YawSource[grown], 1);
    yawAfterRadians = grown(yawAfterRadians, grown);
    gyroTurnAfterRadians = grown(gyroTurnAfterRadians, grown);
    gyroSecondsAfter = grown(gyroSecondsAfter, grown);
    driftSeenAtRest = grown(driftSeenAtRest, grown);
    driftSeenVariance = grown(driftSeenVariance, grown);
    turnReopenedBy =
        grown(
            turnReopenedBy,
            new double[grown * ConsideredErrors.MAX_CAMERAS],
            ConsideredErrors.MAX_CAMERAS);
    carriedXAfter = grown(carriedXAfter, grown);
    carriedYAfter = grown(carriedYAfter, grown);
    carriedVarianceAfter = grown(carriedVarianceAfter, grown);
    filterXAfter = grown(filterXAfter, grown);
    filterYAfter = grown(filterYAfter, grown);
    filterHeadingOffsetAfter = grown(filterHeadingOffsetAfter, grown);
    filterGyroScaleAfter = grown(filterGyroScaleAfter, grown);
    filterGyroDriftAfter = grown(filterGyroDriftAfter, grown);
    filterUncertaintyAfter =
        grown(filterUncertaintyAfter, new double[grown * uncertaintyLength], uncertaintyLength);
    oldestSlot = 0;
    capacity = grown;
  }

  private double[] grown(double[] kept, int grown) {
    return grown(kept, new double[grown], 1);
  }

  /**
   * Copies the steps kept into a larger array, in order from the oldest, which goes first.
   *
   * @param perSlot how many of the array's numbers each slot holds
   */
  private <A> A grown(A kept, A into, int perSlot) {
    for (int step = 0; step < stepCount; step++) {
      System.arraycopy(kept, slotOf(step) * perSlot, into, step * perSlot, perSlot);
    }
    return into;
  }
}
